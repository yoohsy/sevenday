using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace UnityOpenMcpBridge.MetaTools
{
    // M27 Plan 4 — live `batch_execute`.
    //
    // One HTTP round trip runs many typed tools sequentially inside the
    // already-open Editor. NOT the headless batch spawn fallback — this tool
    // is `batchCapable: false` (not in BATCH_TOOL_NAMES); it requires the live
    // bridge to be up. The MCP server never falls back to spawning Unity.
    //
    // This class owns:
    //   1. Parsing + validating the `commands` array (count limit, tool
    //      allow/deny-list, schema presence).
    //   2. Running each command via the SAME dispatch path as a single tool
    //      (`BridgeHttpServer.DispatchTool`) — no business-logic duplication.
    //   3. Per-step result collection + fail_fast abort + skipped tail.
    //   4. BridgeBatchRunHistory live progress (BeginRun / AddEntry /
    //      SetEntryStatus / CompleteRun).
    //
    // The batch-level GATE (one checkpoint → N steps → one validate/delta) and
    // the undo grouping live in `BatchExecuteGateRunner` (the gate-runner
    // analogue of `ApplyFixGateRunner`), which wraps this Execute() in a
    // GatePolicy.Execute cycle. Execute() itself is just the "mutation lambda"
    // from the gate's perspective — it runs the steps and returns a single
    // ToolDispatchResult carrying the per-step results envelope.
    public static class BatchExecuteTool
    {
        // Default cap on nested commands. Overridable via
        // BridgeProjectSettings.BatchExecuteMaxCommands (clamped 1–100):
        // 25 default, 100 hard max.
        public const int DefaultMaxCommands = 25;
        public const int HardMaxCommands = 100;

        // v1 deny-list: tools that must NOT be invoked as nested batch steps for
        // reasons OTHER than lifecycle. Tools that force a domain reload or scene
        // switch are denied via the lifecycle-derived check in IsNestedReloadUnsafe
        // (so the deny-list stays accurate as new RestartThenSettle tools are
        // added without re-touching this list). This explicit set covers:
        //   - batch_execute itself (no nesting — would recurse).
        //   - compile_check (always headless spawn; cannot run live).
        // The local-only tools (capabilities, manage_tools, hub_*,
        // read_compile_errors, bridge_status, generate_skill, pull_events) are
        // rejected dynamically because they are NOT in the bridge's KnownTools
        // set — a nested step naming one of them dispatches to tool_not_found,
        // which is surfaced as a per-step error (matching the MCP contract's
        // `batch_tool_not_invokable`).
        private static readonly HashSet<string> DeniedNestedTools = new HashSet<string>
        {
            "unity_open_mcp_batch_execute",
            ProjectCommandInvocation.ToolName,
            "unity_open_mcp_compile_check",
            "unity_open_mcp_editor_undo",
            "unity_open_mcp_editor_redo",
            "unity_open_mcp_editor_clear_history",
        };

        // specs/feedback.md 2026-08-24 — tools whose TERMINAL result is produced
        // by the MCP SERVER, not by this dispatch.
        //
        // run_tests returns {status:"started", runId} immediately (Execute is
        // deferred to an editor tick so it cannot wedge the dispatch queue) and
        // the server turns that into a real result by polling
        // ~/.unity-open-mcp/test-results-<runId>.json — a special case in
        // LiveClient.route, ahead of the generic tool POST. A nested batch step
        // goes straight through BridgeHttpServer.DispatchTool, which knows
        // nothing about that poller, so the step is recorded `success` carrying
        // the non-terminal "started" body and the caller never learns the run's
        // outcome. The field report burned a full session on exactly this: the
        // batch answered `started` and nothing else, forever.
        //
        // Note this is NOT the same axis as the capability surface's
        // `batchCapable` flag, which means "has a HEADLESS batch-spawn fallback
        // when the bridge is down" — a different question with a coincidentally
        // similar answer for this tool. Keep the two independent.
        //
        // inputsim_gesture, playtest_wait and capture_series are the same shape on
        // a different poller: their call only starts an operation on the
        // play-mode scheduler, and the frames that run it cannot advance while a
        // batch holds the main thread.
        private static readonly HashSet<string> ServerPolledTools = new HashSet<string>
        {
            "unity_senses_run_tests",
            "unity_open_mcp_inputsim_gesture",
            "unity_open_mcp_playtest_wait",
            "unity_senses_capture_series",
        };

        // specs/feedback.md 2026-08-24 — every pre-flight refusal below tells the
        // caller to "use it as a single top-level call instead". That is the right
        // advice, EXCEPT for the client shape the field report hit: a client that
        // does not re-issue tools/list on `tools/list_changed` cannot see a tool
        // that manage_tools just activated, so the top-level call it is pointed at
        // does not exist for it, and the refusal is a dead end. Where a concrete
        // meta-tool equivalent exists, name it — an agent can always reach
        // execute_csharp / invoke_method (they are in the always-visible `core`
        // group). Returns null when there is no honest one-liner, in which case
        // the caller gets the top-level advice alone rather than a made-up
        // workaround.
        private static string NestedAlternativeHint(string tool)
        {
            switch (tool)
            {
                case "unity_open_mcp_recompile_scripts":
                    return "If your client cannot see the top-level tool (a manage_tools activation " +
                           "whose tools/list_changed it ignored), the equivalent is one " +
                           "execute_csharp call with read_only:true — " +
                           "`UnityEditor.Compilation.CompilationPipeline.RequestScriptCompilation(); " +
                           "return \"requested\";` — then poll editor_status until isCompiling is " +
                           "false. That is what this tool does; it only adds the before/after " +
                           "Library/ScriptAssemblies mtimes that make a no-op recompile detectable.";
                case "unity_senses_run_tests":
                    return "If your client cannot see the top-level tool (a manage_tools activation " +
                           "whose tools/list_changed it ignored), invoke the test class or method " +
                           "directly with invoke_method — NUnit assertion failures come back verbatim " +
                           "in the error — or drive UnityEditor.TestTools.TestRunner.Api.TestRunnerApi " +
                           "from an execute_csharp snippet. Neither gets the results-file poll, so " +
                           "keep each call inside the transport timeout.";
                default:
                    return null;
            }
        }

        // Append the reachable-alternative hint to a refusal message when one
        // exists. Kept separate from the message text so every refusal path
        // reads the same and a new hint lands everywhere at once.
        private static string WithAlternative(string message, string tool)
        {
            var hint = NestedAlternativeHint(tool);
            return hint == null ? message : message + " " + hint;
        }

        // M30-polish Plan 5 / T5.2 — a nested step that resolves to the
        // RestartThenSettle lifecycle would force a domain reload (package add /
        // remove / reimport, asmdef edit, build_set_defines/target, settings_set
        // player) or a scene switch (scene_open Single mode), silently aborting
        // every later step in the batch (the bridge's RestartThenSettle settle
        // wait can't bridge a mid-batch reload). Deriving the deny-list from the
        // lifecycle taxonomy catches the whole class as new RestartThenSettle
        // tools are added, instead of hardcoding each tool name. Returns the
        // resolved lifecycle so the caller can build a precise error message.
        //
        // scene_create is RestartThenSettle too, but its unsafety is MODE-
        // DEPENDENT: Single mode replaces the scene stack (unsafe mid-batch),
        // while additive mode preserves it (safe). It is therefore carved out
        // here and handled by the param-aware IsNestedSceneStackUnsafe check,
        // which runs FIRST (see the call site). scene_open has no additive-safe
        // case in the batch context and stays caught here. (B-N9.)
        private static bool IsNestedReloadUnsafe(string toolName, string body, out LifecyclePolicy policy)
        {
            policy = EffectiveToolContract.Lifecycle(toolName, body);
            if (policy != LifecyclePolicy.RestartThenSettle) return false;
            // scene_create's safety depends on its `mode` param; the param-aware
            // IsNestedSceneStackUnsafe check (run before this one at the call
            // site) decides, so additive scene_create is not lumped into the
            // unconditional reload-unsafe refusal here.
            if (toolName == "unity_open_mcp_scene_create") return false;
            return true;
        }

        // scene_create defaults to NewSceneMode.Single, which replaces the active
        // scene stack — a mid-batch Single create silently discards unsaved
        // changes in the currently-open scenes, the same disruption class T5.2
        // targets. scene_open IS ReloadUnsafe and is already caught by the
        // lifecycle check above; scene_create is carved out of that check so its
        // mode can be inspected here. Additive mode preserves the scene stack and
        // is allowed. (B-N9 — this check MUST run before IsNestedReloadUnsafe so
        // an additive scene_create is accepted instead of refused wholesale.)
        private const string SingleModeReason =
            "defaults to Single mode (or has mode:\"single\"), which replaces the " +
            "active scene stack and can discard unsaved changes in open scenes";

        private static bool IsNestedSceneStackUnsafe(string toolName, string paramsBody, out string reason)
        {
            reason = null;
            if (toolName != "unity_open_mcp_scene_create")
                return false;
            var mode = JsonBody.GetString(paramsBody, "mode");
            // Additive preserves the scene stack; anything else (absent default
            // or explicit "single") replaces it.
            if (!string.IsNullOrEmpty(mode) && mode.ToLowerInvariant() == "additive")
                return false;
            reason = SingleModeReason;
            return true;
        }

        // feedback-fable-31-07 §3 — a step that writes a .cs file (and so can
        // arm a compile on the next import). script_write is the canonical case;
        // its `file_path` param (the same key script_write/script_read read) is a
        // project-relative .cs path. We treat any .cs script_write step as a
        // script-write for the combo check.
        private static bool IsScriptWriteStep(BatchStep step)
        {
            if (step.Tool != "unity_open_mcp_script_write") return false;
            var path = JsonBody.GetString(step.ParamsBody, "file_path");
            // Only a .cs write arms a compile; script_write rejects non-.cs
            // paths at its own layer, but check here so the combo refusal is
            // precise and does not fire for an unrelated script_write.
            return !string.IsNullOrEmpty(path) && path.EndsWith(".cs", System.StringComparison.OrdinalIgnoreCase);
        }

        // A step that forces an import of pending changes (and thus a compile
        // when a .cs write is pending). assets_refresh with
        // ForceSynchronousImport is the repro trigger and the only nested tool
        // that can land here: reimport_package has the RestartThenSettle
        // lifecycle and is already refused up-front by IsNestedReloadUnsafe, so
        // it never reaches this check.
        private static bool IsImportTriggerStep(BatchStep step)
        {
            return step.Tool == "unity_open_mcp_assets_refresh";
        }

        // Per-step rules that depend only on this one step. Pure over
        // (index, tool, params): the index is a parameter, so a refusal names
        // the real step without rewriting message text. The rules run in a
        // fixed order and the FIRST refusal wins. The deny-list must stay ahead
        // of the lifecycle check: resolving a nested batch_execute's lifecycle
        // would re-enter Preflight.
        private static ToolDispatchResult ValidateStep(int index, string tool, string paramsBody)
        {
            if (string.IsNullOrWhiteSpace(tool))
            {
                return ToolDispatchResult.Fail(
                    "batch_invalid_step",
                    $"commands[{index}] is missing a 'tool' name.");
            }

            // Deny-list check (nesting / headless-only). These are the tools
            // blocked for non-lifecycle reasons; RestartThenSettle tools are
            // blocked separately below with a lifecycle-specific error.
            if (DeniedNestedTools.Contains(tool))
            {
                return ToolDispatchResult.Fail(
                    "batch_tool_not_invokable",
                    WithAlternative(
                        $"commands[{index}] tool '{tool}' is not invokable inside a batch " +
                        "(nesting / headless-only restriction). Use it as a " +
                        "single top-level call instead.",
                        tool));
            }

            // Play-state transitions and a non-dry-run apply_fix need their own
            // top-level runners (lifecycle wait / rollback); a nested step would
            // bypass both.
            if ((tool == "unity_open_mcp_editor_set_state"
                && JsonBody.GetString(paramsBody, "state") != "pause")
                || (tool == "unity_open_mcp_apply_fix" && !JsonBody.GetBool(paramsBody, "dry_run", true)))
                return ToolDispatchResult.Fail("batch_tool_not_invokable",
                    $"commands[{index}] tool '{tool}' requires its top-level lifecycle/rollback runner.");

            // specs/feedback.md 2026-08-24 — a step whose terminal result is
            // produced by the MCP server's results-file poller can never
            // resolve inside a batch: nothing polls, so the step reports
            // `success` with a non-terminal {"status":"started"} body and the
            // run's outcome is unreachable. Refuse up-front rather than
            // silently accepting a call that cannot answer.
            if (ServerPolledTools.Contains(tool))
            {
                return ToolDispatchResult.Fail(
                    "batch_step_requires_server_poll",
                    WithAlternative(
                        $"commands[{index}] tool '{tool}' is not invokable inside a batch: its " +
                        "terminal result is produced by the MCP server polling the bridge " +
                        "(a results file under ~/.unity-open-mcp for tests, POST " +
                        "/playmode-operations for gestures, waits and capture series), and the batch route has no poller. " +
                        "The step would be recorded as success carrying a non-terminal " +
                        "started/running body and the outcome would never reach you. Use it as " +
                        "a single top-level call instead — that route polls to a terminal result.",
                        tool));
            }

            // game_view set_resolution / set_device in play mode return once the
            // game reports the new size, which the MCP server polls on the
            // play-mode scheduler — and no frame advances while a batch holds the
            // main thread. get / list_devices are plain reads and stay allowed.
            if (tool == "unity_open_mcp_game_view")
            {
                var gameViewAction = JsonBody.GetString(paramsBody, "action");
                if (gameViewAction == "set_resolution" || gameViewAction == "set_device")
                    return ToolDispatchResult.Fail(
                        "batch_step_requires_server_poll",
                        $"commands[{index}] tool '{tool}' action '{gameViewAction}' is not invokable inside a batch: " +
                        "it returns once the game reports the new size, which the MCP server polls on the " +
                        "play-mode scheduler, and no frame advances while a batch holds the main thread. " +
                        "Use it as a single top-level call instead (get and list_devices work inside a batch).");
            }

            // B-N9 — scene_create's safety depends on its `mode` param
            // (additive preserves the scene stack; Single replaces it). Run
            // this param-aware check BEFORE the lifecycle-derived reload
            // check: scene_create is RestartThenSettle, so the reload check
            // would otherwise refuse it wholesale even with mode:"additive",
            // contradicting the schema and making this branch dead code.
            // The reload check below carves scene_create out accordingly.
            if (IsNestedSceneStackUnsafe(tool, paramsBody, out var sceneReason))
            {
                return ToolDispatchResult.Fail(
                    "batch_nested_reload_unsafe",
                    $"commands[{index}] tool '{tool}' is not invokable inside a batch: " +
                    $"it {sceneReason}. Pass mode:\"additive\" or use it as a " +
                    "single top-level call instead.");
            }

            // T5.2 — deny RestartThenSettle nested steps. A domain reload
            // or scene switch mid-batch silently aborts every later step
            // (the settle wait can't bridge a reload). Refuse up-front with
            // a clear error naming the offending step and why. scene_create
            // is handled by the param-aware check above and carved out of
            // IsNestedReloadUnsafe so an additive scene_create is accepted.
            if (IsNestedReloadUnsafe(tool, paramsBody, out var unsafePolicy))
            {
                return ToolDispatchResult.Fail(
                    "batch_nested_reload_unsafe",
                    WithAlternative(
                        $"commands[{index}] tool '{tool}' has lifecycle " +
                        $"{unsafePolicy.ToWireString()} and is not invokable inside a batch: " +
                        "it may trigger a domain reload or scene switch that silently aborts " +
                        "the remaining steps. Use it as a single top-level call instead.",
                        tool));
            }

            return null;
        }

        // Cross-step rules over the already-parsed plan. Each step carries its
        // position in the request's `commands` array, so messages stay exact
        // even when the plan omits a step (an unknown tool is never planned).
        //
        // feedback-fable-31-07 §3 — detect a script-write followed (later in
        // the batch) by an import/refresh that will trigger a compile
        // mid-batch. The settle wait runs only ONCE at the batch level after
        // all steps complete; a compile kicked off by assets_refresh after a
        // script_write can kill the HTTP response mid-write (domain reload)
        // before the batch envelope is serialized, producing
        // bridge_response_unparsable. RestartThenSettle tools are already
        // refused per step, but script_write + assets_refresh is the concrete
        // repro from the field report and is not caught by the lifecycle
        // taxonomy (script_write is None, assets_refresh is EditorSettle).
        // Preflight currently refuses every nested script_write outright as
        // well; this rule stays as the precise explanation of the combination
        // and as the guard should that blanket refusal ever be narrowed.
        private static ToolDispatchResult ValidateSequence(IReadOnlyList<BatchStep> steps)
        {
            int scriptWrite = -1;
            for (int s = 0; s < steps.Count; s++)
            {
                if (IsScriptWriteStep(steps[s]))
                {
                    scriptWrite = s;
                    break;
                }
            }
            if (scriptWrite < 0) return null;
            for (int s = scriptWrite + 1; s < steps.Count; s++)
            {
                if (!IsImportTriggerStep(steps[s])) continue;
                return ToolDispatchResult.Fail(
                    "batch_nested_reload_unsafe",
                    $"commands[{steps[scriptWrite].Index}] writes a script and commands[{steps[s].Index}] " +
                    $"('{steps[s].Tool}') would trigger a compile mid-batch, which can " +
                    "kill the HTTP response mid-write via a domain reload before the " +
                    "batch result is sent. Write the script as a single top-level call, " +
                    "let it settle, then run the remaining steps in a separate batch.");
            }
            return null;
        }

        internal static ToolDispatchResult Preflight(string body, out bool isMutating)
            => Preflight(body, out isMutating, out _);

        // `envelopeValidated`: the HTTP handler already validated this body
        // against the batch_execute request schema at the transport boundary.
        internal static ToolDispatchResult Preflight(string body, out bool isMutating, out BatchPlan plan, bool envelopeValidated = false)
        {
            isMutating = false;
            plan = new BatchPlan();
            if (!BridgeJson.IsCompleteJson(body))
                return ToolDispatchResult.Fail("batch_invalid_step", "Batch request must be one complete JSON object.");
            var rawCommands = JsonBody.GetTopLevelRawValue(body, "commands");
            if (rawCommands == null || !rawCommands.TrimStart().StartsWith("["))
                return ToolDispatchResult.Fail("missing_parameter", "'commands' must be a non-empty array.");
            var commands = JsonBody.GetArrayRawValues(rawCommands);
            if (commands.Count == 0)
                return ToolDispatchResult.Fail("missing_parameter", "'commands' must be a non-empty array.");
            int limit = System.Math.Max(1, System.Math.Min(HardMaxCommands, BridgeProjectSettings.BatchExecuteMaxCommands));
            if (commands.Count > limit)
                return ToolDispatchResult.Fail(
                    "batch_too_many_commands",
                    $"Batch has {commands.Count} commands; the limit is {limit} " +
                    "(configurable via .unity-open-mcp/settings.json 'batchExecuteMaxCommands', " +
                    $"hard max {HardMaxCommands}). Split the batch or raise the limit.");
            var errors = new List<string>();
            if (!envelopeValidated) BatchSchemaValidator.ValidateRequest(body, BridgeBatchSchemas.ByTool["unity_open_mcp_batch_execute"], errors);
            string errorCode = errors.Count == 0 ? null : "batch_invalid_step";
            // One pass: every command is parsed once, and the same params value
            // feeds the per-step rules, the schema check and the dispatch plan.
            for (int i = 0; i < commands.Count; i++)
            {
                var raw = commands[i];
                var tool = JsonBody.GetString(JsonBody.TopLevelField(raw, "tool"), "tool");
                // Absent params means an empty argument object. An explicit
                // `params: null` is kept as-is: the published schema types params
                // as an object, so the schema check below rejects it exactly as
                // the MCP server and the transport-boundary validation do.
                var args = JsonBody.GetTopLevelRawValue(raw, "params") ?? "{}";
                var stepRefusal = ValidateStep(i, tool, args);
                if (stepRefusal != null)
                {
                    errorCode = errorCode ?? stepRefusal.ErrorCode;
                    errors.Add(stepRefusal.ErrorMessage);
                }
                foreach (var key in JsonBody.GetObjectKeys(raw) ?? new List<string>())
                    if (key != "tool" && key != "params")
                    {
                        errorCode = errorCode ?? "batch_invalid_step";
                        errors.Add("commands[" + i + "]." + key + " is unknown");
                    }
                if (string.IsNullOrWhiteSpace(tool)) continue;
                bool known = BridgeToolClassification.KnownTools.Contains(tool) || BridgeToolRegistry.TryGet(tool, out _);
                if (!known)
                {
                    errorCode = errorCode ?? "batch_tool_not_invokable";
                    errors.Add("commands[" + i + "] tool '" + tool + "' is not available in the live bridge. Use its top-level route.");
                    continue;
                }
                if (BridgeToolTogglePolicy.IsDisabled(tool))
                {
                    errorCode = errorCode ?? "batch_tool_not_invokable";
                    errors.Add("commands[" + i + "] tool '" + tool + "' is disabled in the bridge.");
                }
                if (BridgeBatchSchemas.ByTool.TryGetValue(tool, out var schema))
                {
                    int before = errors.Count;
                    BatchSchemaValidator.Validate(args, schema, "commands[" + i + "].params", errors, true);
                    if (errors.Count != before) errorCode = errorCode ?? "batch_invalid_step";
                }
                else
                {
                    errorCode = errorCode ?? "batch_tool_not_invokable";
                    errors.Add("commands[" + i + "] has no published batch schema; call the tool top-level instead.");
                }
                if (tool == "unity_open_mcp_script_write" || tool == "unity_open_mcp_script_delete")
                {
                    errorCode = errorCode ?? "batch_nested_reload_unsafe";
                    errors.Add("commands[" + i + "] tool '" + tool + "' imports/deletes scripts and may reload the domain. Call it top-level and wait for compilation.");
                }
                bool stepMutating = tool != "unity_open_mcp_batch_execute" && EffectiveToolContract.IsMutating(tool, args);
                isMutating |= stepMutating;
                plan.Steps.Add(new BatchStep { Index = i, Tool = tool, ParamsBody = args, IsMutating = stepMutating });
            }
            plan.IsMutating = isMutating;
            var sequenceRefusal = ValidateSequence(plan.Steps);
            if (sequenceRefusal != null)
            {
                errorCode = errorCode ?? sequenceRefusal.ErrorCode;
                errors.Add(sequenceRefusal.ErrorMessage);
            }
            if (errors.Count == 0) return null;
            return ToolDispatchResult.Fail(errorCode ?? "batch_invalid_step", string.Join("\n", errors));
        }

        public static ToolDispatchResult Execute(string body)
        {
            var refusal = Preflight(body, out _, out var plan);
            if (refusal != null) return refusal;
            return Execute(body, plan);
        }

        // Dispatch loop for an already-preflighted request. Callers that hold a
        // plan from Preflight (the HTTP handler via BatchExecuteGateRunner) use
        // this entry so the body is not parsed and validated a second time.
        internal static ToolDispatchResult Execute(string body, BatchPlan plan)
        {
            var sw = Stopwatch.StartNew();
            bool failFast = JsonBody.GetBool(JsonBody.TopLevelField(body, "fail_fast"), "fail_fast", true);
            var steps = plan.Steps;
            // --- BridgeBatchRunHistory live progress -------------------------
            // One BeginRun / CompleteRun pair around the whole loop so the
            // operator's Activity Batch section shows in-flight progress without
            // a manual refresh. Source "mcp" distinguishes agent-driven batches
            // from any future Hub-initiated runs.
            var runId = System.Guid.NewGuid().ToString("N");
            var label = BuildRunLabel(steps);
            BridgeBatchRunHistory.BeginRun(runId, "mcp", label);

            try
            {
                // --- Sequential dispatch loop --------------------------------
                var results = new List<BatchStepResult>(steps.Count);
                int successCount = 0;
                int committedCount = 0;
                int failureCount = 0;
                bool aborted = false;

                for (int i = 0; i < steps.Count; i++)
                {
                    var step = steps[i];

                    // If a prior step failed under fail_fast, mark the rest
                    // skipped (NOT executed) — matches the MCP contract.
                    if (aborted)
                    {
                        BridgeBatchRunHistory.AddEntry(step.Tool, SummarizeArgs(step));
                        BridgeBatchRunHistory.SetEntryStatus(i, BridgeBatchEntryStatus.Skipped);
                        results.Add(new BatchStepResult
                        {
                            Index = i,
                            Tool = step.Tool,
                            Status = "skipped",
                        });
                        continue;
                    }

                    var entry = BridgeBatchRunHistory.AddEntry(step.Tool, SummarizeArgs(step));
                    BridgeBatchRunHistory.SetEntryStatus(i, BridgeBatchEntryStatus.Running);

                    var stepSw = Stopwatch.StartNew();
                    ToolDispatchResult stepResult;
                    try
                    {
                        // Reuse the EXACT per-tool dispatch path. This runs
                        // the typed/meta-tool handler with the step's params;
                        // paths_hint/gate are NOT re-enforced per step (the
                        // batch owns one gate cycle for the whole sequence —
                        // see BatchExecuteGateRunner).
                        stepResult = BridgeHttpServer.DispatchTool(step.Tool, step.ParamsBody);
                    }
                    catch (System.Exception e)
                    {
                        // A thrown handler is treated as a step failure (the
                        // outer gate runner catches checkpoint/validate throws;
                        // this only fires for a handler that threw inside
                        // DispatchTool, which the switch does not wrap).
                        stepResult = ToolDispatchResult.Fail("execution_error", e.Message);
                    }
                    stepSw.Stop();

                    if (stepResult.Success)
                    {
                        successCount++;
                        if (step.IsMutating) committedCount++;
                        BridgeBatchRunHistory.SetEntryStatus(i, BridgeBatchEntryStatus.Done, stepSw.ElapsedMilliseconds);
                        results.Add(new BatchStepResult
                        {
                            Index = i,
                            Tool = step.Tool,
                            Status = "success",
                            Output = stepResult.Output,
                        });
                    }
                    else
                    {
                        failureCount++;
                        BridgeBatchRunHistory.SetEntryStatus(
                            i, BridgeBatchEntryStatus.Failed, stepSw.ElapsedMilliseconds,
                            stepResult.ErrorCode, stepResult.ErrorMessage);
                        results.Add(new BatchStepResult
                        {
                            Index = i,
                            Tool = step.Tool,
                            Status = "failed",
                            ErrorCode = stepResult.ErrorCode,
                            ErrorMessage = stepResult.ErrorMessage,
                        });
                        if (failFast)
                        {
                            aborted = true;
                        }
                    }
                }

                sw.Stop();

                // Batch-level success = every step succeeded. A failed/skipped
                // step must propagate to the ToolDispatchResult.Success flag so
                // the gate envelope's `mutation.success` and the gate runner's
                // partial-failure branch (BatchExecuteGateRunner) fire. The
                // per-step detail is always present in the output regardless.
                // Returning Ok(...) here would hardcode Success=true (see
                // ToolDispatchResult.Ok) and make the "one or more steps failed"
                // guidance dead code — code-review finding B1.
                //
                // B-N10 — when at least one step committed (successCount > 0)
                // the failure is PARTIAL: stamp PartialCommit = true via the
                // PartialFailure factory so GatePolicy still runs the post-
                // mutation validate/delta on the committed work (instead of
                // returning right after the mutation) and BridgeHttpServer still
                // waits for the asset/compile settle. A total failure
                // (successCount == 0) keeps the old shape — nothing committed,
                // so there is nothing to health-check.
                bool batchSuccess = failureCount == 0;
                string batchOutput = BuildBatchOutput(
                    batchSuccess, successCount, failureCount, failFast, results, sw.ElapsedMilliseconds);
                if (batchSuccess)
                {
                    return ToolDispatchResult.Ok(batchOutput);
                }
                if (committedCount > 0)
                {
                    return ToolDispatchResult.PartialFailure(
                        "batch_partial_failure",
                        failureCount + " batch step(s) failed; inspect batch.results[] for per-step " +
                        "status and error detail. Successful steps before the failure are committed " +
                        "(v1 does not roll them back) — undo with a single editor_undo if needed.",
                        batchOutput);
                }
                return new ToolDispatchResult(
                    false, batchOutput, "batch_partial_failure",
                    failureCount + " batch step(s) failed; inspect batch.results[] for per-step " +
                    "status and error detail. Successful steps before the failure are committed " +
                    "(v1 does not roll them back) — undo with a single editor_undo if needed.");
            }
            finally
            {
                BridgeBatchRunHistory.CompleteRun(runId);
            }
        }

        // Build the redacted run label from the step tool names (no full params
        // dump — keeps the Activity Batch section readable and avoids leaking payloads).
        private static string BuildRunLabel(List<BatchStep> steps)
        {
            if (steps.Count == 0) return "batch_execute";
            var sb = new StringBuilder(64);
            sb.Append("batch (").Append(steps.Count).Append("): ");
            for (int i = 0; i < steps.Count && i < 3; i++)
            {
                if (i > 0) sb.Append(", ");
                // Short tool suffix (drop the unity_open_mcp_ prefix).
                var t = steps[i].Tool;
                const string prefix = "unity_open_mcp_";
                sb.Append(t.StartsWith(prefix) ? t.Substring(prefix.Length) : t);
            }
            if (steps.Count > 3) sb.Append(", …");
            return sb.ToString();
        }

        // Per-entry args summary for the Activity Batch section. Redacted to the tool name +
        // a short hint of the first key id-like param — never the full params
        // body (could be large / sensitive).
        private static string SummarizeArgs(BatchStep step)
        {
            var name = JsonBody.GetString(step.ParamsBody, "name");
            var assetPath = JsonBody.GetString(step.ParamsBody, "asset_path");
            var path = JsonBody.GetString(step.ParamsBody, "path");
            if (!string.IsNullOrWhiteSpace(name)) return "name=" + Truncate(name, 60);
            if (!string.IsNullOrWhiteSpace(assetPath)) return "asset_path=" + Truncate(assetPath, 60);
            if (!string.IsNullOrWhiteSpace(path)) return "path=" + Truncate(path, 60);
            return null;
        }

        private static string Truncate(string s, int max)
        {
            if (string.IsNullOrEmpty(s)) return s;
            return s.Length <= max ? s : s.Substring(0, max) + "…";
        }

        // Compose the batch output JSON. Mirrors the response shape documented
        // in the MCP tool contract (execution-plan-4 T27.4.1).
        //
        //   {
        //     "batch": {
        //       "success": true,
        //       "callSuccessCount": 3,
        //       "callFailureCount": 0,
        //       "failFast": true,
        //       "results": [
        //         { "index": 0, "tool": "...", "status": "success", "output": {…} },
        //         { "index": 1, "tool": "...", "status": "failed", "error": { "code":…, "message":… } },
        //         { "index": 2, "tool": "...", "status": "skipped" }
        //       ]
        //     }
        //   }
        private static string BuildBatchOutput(
            bool success, int successCount, int failureCount, bool failFast,
            List<BatchStepResult> results, long durationMs)
        {
            var sb = new StringBuilder(1024);
            sb.Append("{\"batch\":{");
            sb.Append("\"success\":").Append(success ? "true" : "false");
            sb.Append(",\"callSuccessCount\":").Append(successCount);
            sb.Append(",\"callFailureCount\":").Append(failureCount);
            sb.Append(",\"failFast\":").Append(failFast ? "true" : "false");
            sb.Append(",\"durationMs\":").Append(durationMs);
            sb.Append(",\"results\":[");
            for (int i = 0; i < results.Count; i++)
            {
                if (i > 0) sb.Append(',');
                results[i].WriteJson(sb);
            }
            sb.Append("]}}");
            return sb.ToString();
        }

        internal struct BatchStep
        {
            // Position in the request's `commands` array. Equals the plan
            // position whenever the plan is executed (any refused step refuses
            // the whole batch); it differs only in refusal messages, where an
            // unknown tool was left out of the plan.
            public int Index;
            public string Tool;
            public string ParamsBody;
            // Resolved once during preflight so the dispatch loop does not
            // re-derive the effective contract per step.
            public bool IsMutating;
        }

        // Preflight output handed down the dispatch chain (HTTP handler → gate
        // runner → dispatch loop) so one request is parsed and validated once.
        internal sealed class BatchPlan
        {
            public readonly List<BatchStep> Steps = new List<BatchStep>();
            public bool IsMutating;
        }

        private struct BatchStepResult
        {
            public int Index;
            public string Tool;
            public string Status; // "success" | "failed" | "skipped"
            public string Output; // raw JSON object (success only)
            public string ErrorCode;
            public string ErrorMessage;

            public void WriteJson(StringBuilder sb)
            {
                sb.Append("{\"index\":").Append(Index);
                sb.Append(",\"tool\":\"");
                BridgeJson.EscapeStringContentTo(sb, Tool ?? "");
                sb.Append("\",\"status\":\"").Append(Status).Append("\"");
                if (Output != null)
                {
                    // feedback-01-08-glm §4 — a nested tool's serialized Output
                    // is spliced RAW into the batch envelope. If a deep/large
                    // serialization (e.g. object_get_data) emits truncated or
                    // unbalanced JSON — an exception escaping the per-member
                    // try/catch in OutputSerializer — the whole envelope becomes
                    // invalid and the MCP side rejects it as
                    // bridge_response_unparsable, even though the batch itself
                    // ran fine. Validate before splicing (mirrors the guard in
                    // ExecuteCSharpTool.Execute) and substitute a structured
                    // per-step error on failure so the envelope stays well-
                    // formed and the agent sees WHICH step produced bad output.
                    if (BridgeJson.IsValidJsonObject(Output))
                    {
                        sb.Append(",\"output\":").Append(Output);
                    }
                    else
                    {
                        sb.Append(",\"output\":{\"output_parse_failed\":true}");
                        sb.Append(",\"error\":{\"code\":\"output_not_json\"")
                          .Append(",\"message\":\"Step output was not valid JSON and was elided to keep the batch response parseable. Re-run this tool as a top-level call to inspect the raw output.\"}");
                    }
                }
                if (ErrorCode != null)
                {
                    sb.Append(",\"error\":{\"code\":\"");
                    BridgeJson.EscapeStringContentTo(sb, ErrorCode);
                    sb.Append("\",\"message\":\"");
                    BridgeJson.EscapeStringContentTo(sb, ErrorMessage ?? "");
                    sb.Append("\"}");
                }
                sb.Append('}');
            }
        }
    }
}
