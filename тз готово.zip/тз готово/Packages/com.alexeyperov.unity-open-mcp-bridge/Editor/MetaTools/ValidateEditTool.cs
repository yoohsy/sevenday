using System.Text;
using UnityOpenMcpVerify;
using UnityOpenMcpVerify.Batch;
using UnityOpenMcpVerify.Fixes;

namespace UnityOpenMcpBridge.MetaTools
{
    public static class ValidateEditTool
    {
        public static ToolDispatchResult Execute(string body)
        {
            var paths = JsonBody.GetStringArray(body, "paths");
            if (paths == null || paths.Length == 0)
                return ToolDispatchResult.Fail("missing_parameter",
                    "'paths' is required and must be a non-empty array.");

            var categories = JsonBody.GetStringArray(body, "categories");
            var includeRules = JsonBody.GetStringArray(body, "include_rules");
            var excludeRules = JsonBody.GetStringArray(body, "exclude_rules");

            FilteredVerifyResult filtered;
            try
            {
                filtered = VerifyGateAdapter.ValidateFiltered(paths, categories, includeRules, excludeRules);
            }
            catch (System.Exception e)
            {
                return ToolDispatchResult.Fail("validation_error", e.Message);
            }

            var result = filtered.Result;

            if (result.HasUnknownRules)
                return ToolDispatchResult.Ok(
                    BuildUnknownRulesError(result.UnknownRuleIds, result.AvailableRuleIds));

            return ToolDispatchResult.Ok(BuildResult(result, filtered.RulesApplied));
        }

        private static string BuildResult(VerifyResult result, string[] rulesApplied)
        {
            var sb = new StringBuilder(1024);
            // validate_edit is the gate's pre-mutation check; it fails on any
            // Error. The project severity threshold flows into scan_paths and
            // the regression gate; here the contract is strict-error because
            // validate_edit answers "is this asset currently healthy?".
            var hasErrors = result.Issues.Exists(i => i.Severity == VerifySeverity.Error);

            sb.Append("{\"passed\":").Append(!hasErrors ? "true" : "false");
            sb.Append(",\"issues\":[");
            for (int i = 0; i < result.Issues.Count; i++)
            {
                if (i > 0) sb.Append(',');
                var issue = result.Issues[i];
                sb.Append('{');
                var issueId = IssueKey.TryBuild(issue);
                if (issueId == null) sb.Append("\"issueId\":null,");
                else sb.Append("\"issueId\":\"").Append(Esc(issueId)).Append("\",");
                // categoryId mirrors ruleId so agents can match the catalog
                // field (T2.6).
                sb.Append("\"ruleId\":\"").Append(Esc(issue.RuleId)).Append("\",");
                sb.Append("\"categoryId\":\"").Append(Esc(issue.RuleId)).Append("\",");
                sb.Append("\"severity\":\"").Append(SeverityStr(issue.Severity)).Append("\",");
                // B-N14 — `code` is the BARE catalog code an agent matches
                // against the rule-catalog / SKILL.md; `issueCode` carries the
                // full key-discriminator form IssueKey.Build uses for delta
                // tracking and apply_fix targeting. See ScanPathsTool for the
                // full rationale.
                var bareCode = IssueKey.BareIssueCode(issue.IssueCode);
                sb.Append("\"code\":\"").Append(Esc(bareCode)).Append("\",");
                sb.Append("\"issueCode\":\"").Append(Esc(issue.IssueCode)).Append("\",");
                sb.Append("\"assetPath\":\"").Append(Esc(issue.AssetPath)).Append("\",");
                sb.Append("\"description\":\"").Append(Esc(issue.Description)).Append("\"");

                // M25 Plan 3 — explainability (see ScanPathsTool for details).
                // The explainability / registry lookups key on the bare code
                // (computed above for the `code` wire field). CanFix handles
                // both forms.
                if (IssueExplainability.TryGet(issue.RuleId, bareCode, out var explain))
                {
                    sb.Append(",\"rootCause\":\"").Append(Esc(explain.RootCause)).Append("\"");
                    sb.Append(",\"remediation\":\"").Append(Esc(explain.Remediation)).Append("\"");
                }
                if (issue.Evidence != null && issue.Evidence.Count > 0)
                {
                    sb.Append(",\"evidence\":{");
                    int ei = 0;
                    foreach (var kv in issue.Evidence)
                    {
                        if (ei++ > 0) sb.Append(',');
                        sb.Append('"').Append(Esc(kv.Key)).Append("\":\"").Append(Esc(kv.Value ?? "")).Append('"');
                    }
                    sb.Append('}');
                }
                var candidates = FixProviderRegistry.CandidatesForIssue(issue.RuleId, bareCode);
                if (candidates.Length > 0)
                {
                    sb.Append(",\"fixCandidates\":[");
                    for (int ci = 0; ci < candidates.Length; ci++)
                    {
                        if (ci > 0) sb.Append(',');
                        sb.Append("{\"fixId\":\"").Append(Esc(candidates[ci].FixId)).Append("\"");
                        sb.Append(",\"safe\":").Append(candidates[ci].Safe ? "true" : "false");
                        sb.Append('}');
                    }
                    sb.Append(']');
                }
                if (FixProviderRegistry.TryGetFixInfo(issue.RuleId, bareCode, out var fixId, out var safe))
                {
                    sb.Append(",\"fixId\":\"").Append(Esc(fixId)).Append("\"");
                    sb.Append(",\"fixSafe\":").Append(safe ? "true" : "false");
                }
                sb.Append('}');
            }
            sb.Append(']');

            sb.Append(",\"categoriesRun\":[");
            if (result.CategoriesRun != null)
            {
                for (int i = 0; i < result.CategoriesRun.Length; i++)
                {
                    if (i > 0) sb.Append(',');
                    sb.Append('"').Append(Esc(result.CategoriesRun[i])).Append('"');
                }
            }
            sb.Append(']');

            sb.Append(",\"rulesApplied\":[");
            if (rulesApplied != null)
            {
                for (int i = 0; i < rulesApplied.Length; i++)
                {
                    if (i > 0) sb.Append(',');
                    sb.Append('"').Append(Esc(rulesApplied[i])).Append('"');
                }
            }
            sb.Append(']');

            sb.Append(",\"durationMs\":").Append(result.DurationMs);

            // Rules that threw during the scan — the issues list above is
            // incomplete for them, so passed:true must not be read as
            // "verified healthy" for those rules. Mirrors ScanPathsTool.
            if (result.HasFailedRules)
            {
                sb.Append(",\"rulesFailed\":[");
                for (int i = 0; i < result.RulesFailed.Length; i++)
                {
                    if (i > 0) sb.Append(',');
                    sb.Append('"').Append(Esc(result.RulesFailed[i])).Append('"');
                }
                sb.Append("],\"scanIncomplete\":true");
            }
            sb.Append('}');

            return sb.ToString();
        }

        private static string BuildUnknownRulesError(string[] unknownIds, string[] availableIds)
        {
            var sb = new StringBuilder(256);
            sb.Append("{\"error\":{\"code\":\"unknown_rule\"");
            sb.Append(",\"message\":\"Unknown rule IDs: ")
                .Append(Esc(string.Join(", ", unknownIds))).Append("\"");
            sb.Append(",\"unknownRules\":[");
            for (int i = 0; i < unknownIds.Length; i++)
            {
                if (i > 0) sb.Append(',');
                sb.Append('"').Append(Esc(unknownIds[i])).Append('"');
            }
            sb.Append("],\"availableRules\":[");
            for (int i = 0; i < availableIds.Length; i++)
            {
                if (i > 0) sb.Append(',');
                sb.Append('"').Append(Esc(availableIds[i])).Append('"');
            }
            sb.Append("]}}");
            return sb.ToString();
        }

        private static string SeverityStr(VerifySeverity s) => s switch
        {
            VerifySeverity.Error => "Error",
            VerifySeverity.Warning => "Warning",
            _ => "Info"
        };

        // Single source of truth for JSON string-content escaping is BridgeJson
        // (T30.5). Returns escaped CONTENT (no surrounding quotes), matching the
        // call sites here; preserves the `null ⇒ ""` contract.
        private static string Esc(string s) => BridgeJson.EscapeStringContent(s);
    }
}
