using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class button_hover_plate : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    private const float Scale = 1.08f;
    private static readonly Color Hidden = new Color(0.25f, 0.75f, 1f, 0f);
    private static readonly Color Shown = new Color(0.25f, 0.75f, 1f, 0.28f);
    private static readonly Color Glow = new Color(0.2f, 0.65f, 1f, 0.45f);

    private Image plate;

    private void Awake()
    {
        Image source = GetComponent<Image>();
        RectTransform sourceRect = GetComponent<RectTransform>();
        if (source == null || sourceRect == null || transform.parent == null) return;

        Transform parent = transform.parent;
        int index = transform.GetSiblingIndex();
        RectTransform plateRect = null;
        if (index > 0)
        {
            Transform previous = parent.GetChild(index - 1);
            if (previous.name == "hover plate") plateRect = previous as RectTransform;
        }

        if (plateRect == null)
        {
            GameObject go = new GameObject("hover plate", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            go.transform.SetParent(parent, false);
            go.transform.SetSiblingIndex(index);
            plateRect = go.GetComponent<RectTransform>();
        }

        plateRect.anchorMin = sourceRect.anchorMin;
        plateRect.anchorMax = sourceRect.anchorMax;
        plateRect.pivot = sourceRect.pivot;
        plateRect.anchoredPosition = sourceRect.anchoredPosition;
        plateRect.sizeDelta = sourceRect.sizeDelta * Scale;
        plateRect.localRotation = sourceRect.localRotation;
        plateRect.localScale = sourceRect.localScale;

        plate = plateRect.GetComponent<Image>();
        plate.sprite = source.sprite;
        plate.type = source.type;
        plate.preserveAspect = source.preserveAspect;
        plate.fillCenter = source.fillCenter;
        plate.fillMethod = source.fillMethod;
        plate.fillAmount = source.fillAmount;
        plate.fillOrigin = source.fillOrigin;
        plate.fillClockwise = source.fillClockwise;
        plate.color = Hidden;
        plate.raycastTarget = false;

        Outline outline = plate.GetComponent<Outline>();
        if (outline == null) outline = plate.gameObject.AddComponent<Outline>();
        outline.effectColor = Glow;
        outline.effectDistance = new Vector2(2f, -2f);
        outline.useGraphicAlpha = true;
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        if (plate != null) plate.color = Shown;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        if (plate != null) plate.color = Hidden;
    }
}
