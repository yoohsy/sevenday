using System;
using System.Collections.Generic;
using System.Globalization;

public enum GameVariableType
{
    Int,
    Float,
    Bool,
    String
}

[Serializable]
public struct GameVariable
{
    public GameVariableType type;
    public int intValue;
    public float floatValue;
    public bool boolValue;
    public string stringValue;

    public static GameVariable FromInt(int value)
    {
        GameVariable variable = new GameVariable();
        variable.type = GameVariableType.Int;
        variable.intValue = value;
        return variable;
    }

    public static GameVariable FromFloat(float value)
    {
        GameVariable variable = new GameVariable();
        variable.type = GameVariableType.Float;
        variable.floatValue = value;
        return variable;
    }

    public static GameVariable FromBool(bool value)
    {
        GameVariable variable = new GameVariable();
        variable.type = GameVariableType.Bool;
        variable.boolValue = value;
        return variable;
    }

    public static GameVariable FromString(string value)
    {
        GameVariable variable = new GameVariable();
        variable.type = GameVariableType.String;
        variable.stringValue = value ?? string.Empty;
        return variable;
    }

    public double AsNumber()
    {
        switch (type)
        {
            case GameVariableType.Int:
                return intValue;
            case GameVariableType.Float:
                return floatValue;
            case GameVariableType.Bool:
                return boolValue ? 1d : 0d;
            default:
                double parsed;
                if (double.TryParse(stringValue, NumberStyles.Float, CultureInfo.InvariantCulture, out parsed))
                    return parsed;
                return 0d;
        }
    }

    public bool AsBool()
    {
        switch (type)
        {
            case GameVariableType.Int:
                return intValue != 0;
            case GameVariableType.Float:
                return Math.Abs(floatValue) > 0.00001f;
            case GameVariableType.Bool:
                return boolValue;
            default:
                if (string.IsNullOrEmpty(stringValue)) return false;
                if (string.Equals(stringValue, "false", StringComparison.OrdinalIgnoreCase)) return false;
                if (string.Equals(stringValue, "0", StringComparison.OrdinalIgnoreCase)) return false;
                return true;
        }
    }

    public string AsText()
    {
        switch (type)
        {
            case GameVariableType.Int:
                return intValue.ToString(CultureInfo.InvariantCulture);
            case GameVariableType.Float:
                return floatValue.ToString("0.###", CultureInfo.InvariantCulture);
            case GameVariableType.Bool:
                return boolValue ? "true" : "false";
            default:
                return stringValue ?? string.Empty;
        }
    }

    public bool IsNumber()
    {
        return type == GameVariableType.Int || type == GameVariableType.Float;
    }

    public string SerializableValue()
    {
        switch (type)
        {
            case GameVariableType.Int:
                return intValue.ToString(CultureInfo.InvariantCulture);
            case GameVariableType.Float:
                return floatValue.ToString("R", CultureInfo.InvariantCulture);
            case GameVariableType.Bool:
                return boolValue ? "true" : "false";
            default:
                return stringValue ?? string.Empty;
        }
    }

    public static GameVariable FromSerialized(string typeName, string value)
    {
        GameVariableType parsedType = GameVariableType.String;
        if (!string.IsNullOrEmpty(typeName))
        {
            try
            {
                parsedType = (GameVariableType)Enum.Parse(typeof(GameVariableType), typeName, true);
            }
            catch
            {
                parsedType = GameVariableType.String;
            }
        }

        int intResult;
        float floatResult;
        bool boolResult;

        switch (parsedType)
        {
            case GameVariableType.Int:
                if (int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out intResult))
                    return FromInt(intResult);
                return FromInt(0);
            case GameVariableType.Float:
                if (float.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out floatResult))
                    return FromFloat(floatResult);
                return FromFloat(0f);
            case GameVariableType.Bool:
                if (bool.TryParse(value, out boolResult))
                    return FromBool(boolResult);
                return FromBool(!string.IsNullOrEmpty(value) && value != "0");
            default:
                return FromString(value);
        }
    }
}

[Serializable]
public class VariableEntry
{
    public string key;
    public string type;
    public string value;
}

public class GameVariables
{
    private readonly Dictionary<string, GameVariable> values =
        new Dictionary<string, GameVariable>(StringComparer.OrdinalIgnoreCase);

    public event Action<string> Changed;

    public int Count
    {
        get { return values.Count; }
    }

    public IEnumerable<KeyValuePair<string, GameVariable>> All
    {
        get { return values; }
    }

    public void Clear()
    {
        values.Clear();
        if (Changed != null) Changed(null);
    }

    public bool Has(string key)
    {
        if (string.IsNullOrEmpty(key)) return false;
        return values.ContainsKey(key);
    }

    public bool TryGet(string key, out GameVariable variable)
    {
        if (string.IsNullOrEmpty(key))
        {
            variable = new GameVariable();
            return false;
        }
        return values.TryGetValue(key, out variable);
    }

    public void Set(string key, GameVariable variable)
    {
        if (string.IsNullOrEmpty(key)) return;
        values[key] = variable;
        if (Changed != null) Changed(key);
    }

    public void SetInt(string key, int value)
    {
        Set(key, GameVariable.FromInt(value));
    }

    public void SetFloat(string key, float value)
    {
        Set(key, GameVariable.FromFloat(value));
    }

    public void SetBool(string key, bool value)
    {
        Set(key, GameVariable.FromBool(value));
    }

    public void SetString(string key, string value)
    {
        Set(key, GameVariable.FromString(value));
    }

    public int GetInt(string key, int defaultValue = 0)
    {
        GameVariable variable;
        if (TryGet(key, out variable)) return MathfRoundToInt(variable.AsNumber());
        return defaultValue;
    }

    public float GetFloat(string key, float defaultValue = 0f)
    {
        GameVariable variable;
        if (TryGet(key, out variable)) return (float)variable.AsNumber();
        return defaultValue;
    }

    public bool GetBool(string key, bool defaultValue = false)
    {
        GameVariable variable;
        if (TryGet(key, out variable)) return variable.AsBool();
        return defaultValue;
    }

    public string GetString(string key, string defaultValue = "")
    {
        GameVariable variable;
        if (TryGet(key, out variable)) return variable.AsText();
        return defaultValue;
    }

    public void SetNumber(string key, double value)
    {
        double rounded = Math.Round(value);
        if (Math.Abs(value - rounded) < 0.00001d)
            SetInt(key, (int)rounded);
        else
            SetFloat(key, (float)value);
    }

    public void AddNumber(string key, double delta)
    {
        GameVariable variable;
        if (TryGet(key, out variable) && variable.type == GameVariableType.Float)
        {
            SetFloat(key, (float)(variable.AsNumber() + delta));
            return;
        }
        if (TryGet(key, out variable) && variable.type == GameVariableType.String)
        {
            SetString(key, variable.AsText() + delta.ToString("0.###", CultureInfo.InvariantCulture));
            return;
        }
        double current = 0d;
        if (TryGet(key, out variable)) current = variable.AsNumber();
        double result = current + delta;
        double rounded = Math.Round(result);
        if (Math.Abs(result - rounded) < 0.00001d)
            SetInt(key, (int)rounded);
        else
            SetFloat(key, (float)result);
    }

    public void AppendText(string key, string text)
    {
        GameVariable variable;
        string current = string.Empty;
        if (TryGet(key, out variable)) current = variable.AsText();
        SetString(key, current + (text ?? string.Empty));
    }

    public List<VariableEntry> ToEntries()
    {
        List<VariableEntry> entries = new List<VariableEntry>();
        foreach (KeyValuePair<string, GameVariable> pair in values)
        {
            VariableEntry entry = new VariableEntry();
            entry.key = pair.Key;
            entry.type = pair.Value.type.ToString();
            entry.value = pair.Value.SerializableValue();
            entries.Add(entry);
        }
        return entries;
    }

    public void FromEntries(List<VariableEntry> entries)
    {
        values.Clear();
        if (entries != null)
        {
            for (int i = 0; i < entries.Count; i++)
            {
                VariableEntry entry = entries[i];
                if (entry == null || string.IsNullOrEmpty(entry.key)) continue;
                values[entry.key] = GameVariable.FromSerialized(entry.type, entry.value);
            }
        }
        if (Changed != null) Changed(null);
    }

    public string Describe(string key)
    {
        GameVariable variable;
        if (!TryGet(key, out variable)) return "(нет)";
        return variable.AsText();
    }

    private static int MathfRoundToInt(double value)
    {
        return (int)Math.Round(value, MidpointRounding.AwayFromZero);
    }
}
