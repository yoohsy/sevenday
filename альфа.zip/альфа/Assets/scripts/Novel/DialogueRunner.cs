using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class DialogueRunner : MonoBehaviour
{
    private NovelRuntime runtime;
    private DialogueUI ui;
    private NovelView view;
    private DayManager days;

    private DialogueFile file;
    private DialogueNode currentNode;
    private List<DialogueChoice> pendingChoices;
    private string dialogueId;
    private string nodeId;

    private bool dialogueActive;
    private bool waitingForChoice;
    private bool currentNodeWasSeen;
    private bool autoMode;
    private float autoAdvanceAt = -1f;
    private float nextAdvanceTime;
    private int lastChoiceFrame = -1;

    public string DialogueId { get { return dialogueId; } }
    public string NodeId { get { return currentNode != null ? currentNode.id : nodeId; } }
    public bool IsActive { get { return dialogueActive; } }

    public void Init(NovelRuntime runtime, DialogueUI ui, NovelView view, DayManager days)
    {
        this.runtime = runtime;
        this.ui = ui;
        this.view = view;
        this.days = days;
    }

    public bool StartDialogue(string id, string startNode = null, bool applyEffects = true)
    {
        DialogueFile loaded = DialogueLoader.Load(id);
        if (loaded == null)
        {
            Debug.LogError("[Novel] Не удалось запустить диалог: " + id);
            if (ui != null) ui.SetPanelVisible(false);
            return false;
        }

        file = loaded;
        dialogueId = id;
        GameSession.CurrentDialogueId = id;
        pendingChoices = null;
        waitingForChoice = false;
        autoAdvanceAt = -1f;
        dialogueActive = true;
        nextAdvanceTime = Time.unscaledTime + 0.1f;
        if (ui != null)
        {
            ui.SetPanelVisible(true);
            ui.HideChoices();
            ui.SetStatus(string.Empty);
        }

        string target = !string.IsNullOrEmpty(startNode) ? startNode : file.start;
        if (DialogueLoader.GetNode(file, target) == null)
        {
            if (!string.IsNullOrEmpty(startNode))
                Debug.LogWarning("[Novel] Узел не найден: " + startNode + ", начинаем с " + file.start);
            target = file.start;
            applyEffects = true;
        }

        if (string.IsNullOrEmpty(target))
        {
            FinishDialogue();
            return false;
        }

        EnterNode(target, applyEffects);
        return true;
    }

    public bool Resume(string id, string resumeNodeId)
    {
        if (string.IsNullOrEmpty(id)) return false;
        return StartDialogue(id, resumeNodeId, false);
    }

    public void NotifyModalClosed()
    {
        nextAdvanceTime = Time.unscaledTime + 0.2f;
        if (autoMode && !waitingForChoice && (ui == null || !ui.IsTyping))
            autoAdvanceAt = Time.unscaledTime + 0.4f;
    }

    public void Advance()
    {
        if (!dialogueActive) return;
        if (waitingForChoice) return;

        if (ui != null && ui.IsTyping)
        {
            ui.CompleteTyping();
            return;
        }

        if (currentNode == null)
        {
            FinishDialogue();
            return;
        }

        if (currentNode.end || string.IsNullOrEmpty(currentNode.next))
        {
            FinishDialogue();
            return;
        }

        EnterNode(currentNode.next, true);
    }

    public void Choose(DialogueChoice choice)
    {
        if (!dialogueActive || !waitingForChoice || choice == null) return;
        if (lastChoiceFrame == Time.frameCount) return;
        lastChoiceFrame = Time.frameCount;
        waitingForChoice = false;
        if (ui != null) ui.HideChoices();

        NovelEffects.Apply(choice.effects, GameSession.Variables);

        nextAdvanceTime = Time.unscaledTime + 0.2f;
        if (string.IsNullOrEmpty(choice.next))
        {
            FinishDialogue();
            return;
        }

        EnterNode(choice.next, true);
        if (dialogueActive && runtime != null) runtime.SaveAuto();
    }

    public void OnTypingComplete()
    {
        if (!dialogueActive) return;

        if (pendingChoices != null && pendingChoices.Count > 0)
        {
            List<DialogueChoice> choices = pendingChoices;
            pendingChoices = null;
            waitingForChoice = true;
            autoAdvanceAt = -1f;
            if (ui != null) ui.ShowChoices(choices, Choose);
            return;
        }

        if (autoMode)
        {
            float length = ui != null ? ui.CharacterCount : 20;
            autoAdvanceAt = Time.unscaledTime + 0.8f + Mathf.Min(2.5f, length * 0.02f);
        }
    }

    private void EnterNode(string id, bool applyEffects)
    {
        bool suppressEffects = !applyEffects;
        int guard = 0;

        while (guard++ < 64)
        {
            DialogueNode node = DialogueLoader.GetNode(file, id);
            if (node == null)
            {
                Debug.LogWarning("[Novel] Узел не найден: " + id + " в " + dialogueId);
                FinishDialogue();
                return;
            }

            if (!NovelConditions.Evaluate(node.condition, GameSession.Variables))
            {
                string fallback = !string.IsNullOrEmpty(node.elseNext) ? node.elseNext : node.next;
                if (string.IsNullOrEmpty(fallback))
                {
                    FinishDialogue();
                    return;
                }
                id = fallback;
                suppressEffects = false;
                continue;
            }

            if (!suppressEffects)
                NovelEffects.Apply(node.effects, GameSession.Variables);
            suppressEffects = false;

            string formattedText = NovelText.Format(node.text, GameSession.Variables);
            List<DialogueChoice> available = FilterChoices(node.choices);
            bool hasText = !string.IsNullOrEmpty(formattedText);

            if (!hasText && available.Count == 0)
            {
                currentNode = node;
                nodeId = node.id;
                if (node.end || string.IsNullOrEmpty(node.next))
                {
                    FinishDialogue();
                    return;
                }
                id = node.next;
                continue;
            }

            currentNode = node;
            nodeId = node.id;
            GameSession.CurrentNodeId = node.id;
            currentNodeWasSeen = NovelProgress.IsSeen(dialogueId, node.id);
            NovelProgress.MarkSeen(dialogueId, node.id);

            if (view != null)
            {
                view.SetBackground(node.background);
                view.SetCharacter(node.sprite, node.characterPosition);
            }

            pendingChoices = available.Count > 0 ? available : null;
            waitingForChoice = false;
            autoAdvanceAt = -1f;
            nextAdvanceTime = Time.unscaledTime + 0.1f;

            if (ui != null)
            {
                ui.SetPanelVisible(true);
                ui.HideChoices();
                ui.ShowLine(node.speaker, formattedText);
            }

            GameSession.AddHistory(node.speaker, formattedText);
            return;
        }

        Debug.LogError("[Novel] Слишком длинная цепочка узлов (проверьте next/условия).");
        FinishDialogue();
    }

    private List<DialogueChoice> FilterChoices(List<DialogueChoice> choices)
    {
        List<DialogueChoice> result = new List<DialogueChoice>();
        if (choices == null) return result;
        for (int i = 0; i < choices.Count; i++)
        {
            DialogueChoice choice = choices[i];
            if (choice == null) continue;
            if (NovelConditions.Evaluate(choice.condition, GameSession.Variables))
                result.Add(choice);
        }
        return result;
    }

    private void FinishDialogue()
    {
        if (!dialogueActive) return;
        dialogueActive = false;
        waitingForChoice = false;
        pendingChoices = null;
        autoAdvanceAt = -1f;

        DialogueNode finished = currentNode;
        if (ui != null)
        {
            ui.HideChoices();
            ui.SetPanelVisible(false);
            ui.SetStatus(string.Empty);
        }

        if (finished != null && !string.IsNullOrEmpty(finished.nextScene))
        {
            SceneManager.LoadScene(finished.nextScene);
            return;
        }

        if (days != null) days.OnDialogueEnded();
    }

    private void Update()
    {
        if (!dialogueActive || runtime == null) return;

        bool pauseOpen = runtime.Pause != null && runtime.Pause.IsOpen;
        bool backlogOpen = runtime.Backlog != null && runtime.Backlog.IsOpen;

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (backlogOpen)
            {
                runtime.Backlog.Close();
                nextAdvanceTime = Time.unscaledTime + 0.15f;
                return;
            }
            if (runtime.Pause != null)
            {
                runtime.Pause.Toggle();
                nextAdvanceTime = Time.unscaledTime + 0.15f;
            }
            return;
        }

        if (Input.GetKeyDown(KeyCode.H))
        {
            if (!pauseOpen && runtime.Backlog != null)
            {
                runtime.Backlog.Toggle();
                nextAdvanceTime = Time.unscaledTime + 0.15f;
            }
            return;
        }

        if (pauseOpen || backlogOpen) return;

        if (Input.mouseScrollDelta.y > 0.1f && runtime.Backlog != null)
        {
            runtime.Backlog.Open();
            nextAdvanceTime = Time.unscaledTime + 0.15f;
            return;
        }

        if (Input.GetKeyDown(KeyCode.A))
        {
            autoMode = !autoMode;
            if (!autoMode) autoAdvanceAt = -1f;
            else if (!waitingForChoice && (ui == null || !ui.IsTyping))
                autoAdvanceAt = Time.unscaledTime + 0.4f;
        }

        bool skipHeld = Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl);
        bool canSkip = skipHeld && currentNodeWasSeen && !waitingForChoice && currentNode != null;

        if (canSkip)
        {
            if (ui != null && ui.IsTyping)
            {
                ui.CompleteTyping();
            }
            else if (Time.unscaledTime >= nextAdvanceTime)
            {
                Advance();
                nextAdvanceTime = Time.unscaledTime + 0.06f;
            }
            if (ui != null) ui.SetStatus("SKIP");
        }
        else if (autoMode)
        {
            if (ui != null) ui.SetStatus("AUTO");
            if (!waitingForChoice && (ui == null || !ui.IsTyping)
                && autoAdvanceAt > 0f && Time.unscaledTime >= autoAdvanceAt)
            {
                autoAdvanceAt = -1f;
                Advance();
                nextAdvanceTime = Time.unscaledTime + 0.15f;
            }
        }
        else if (ui != null)
        {
            ui.SetStatus(string.Empty);
        }

        bool advancePressed = Input.GetMouseButtonDown(0)
            || Input.GetKeyDown(KeyCode.Space)
            || Input.GetKeyDown(KeyCode.Return)
            || Input.GetKeyDown(KeyCode.KeypadEnter);

        if (advancePressed)
        {
            if (waitingForChoice) return;
            if (Time.unscaledTime < nextAdvanceTime) return;
            Advance();
            nextAdvanceTime = Time.unscaledTime + 0.1f;
        }
    }
}
