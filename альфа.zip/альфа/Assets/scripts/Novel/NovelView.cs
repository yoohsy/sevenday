using System;
using System.Collections.Generic;
using UnityEngine;

public class NovelView : MonoBehaviour
{
    private Camera viewCamera;
    private SpriteRenderer background;
    private SpriteRenderer character;
    private DialogueSpriteLibrary library;
    private string currentBackground;
    private string currentCharacter;

    private static readonly Dictionary<string, Sprite> placeholderCache =
        new Dictionary<string, Sprite>(StringComparer.OrdinalIgnoreCase);

    public void Init()
    {
        viewCamera = Camera.main;
        if (viewCamera == null) viewCamera = UnityEngine.Object.FindObjectOfType<Camera>();
        if (viewCamera == null)
        {
            GameObject cameraObject = new GameObject("Novel Camera");
            cameraObject.transform.SetParent(transform, false);
            cameraObject.transform.position = new Vector3(0f, 0f, -10f);
            viewCamera = cameraObject.AddComponent<Camera>();
            viewCamera.orthographic = true;
            viewCamera.orthographicSize = 5f;
            viewCamera.clearFlags = CameraClearFlags.SolidColor;
            viewCamera.backgroundColor = new Color(0.04f, 0.04f, 0.06f, 1f);
            cameraObject.tag = "MainCamera";
            if (UnityEngine.Object.FindObjectOfType<AudioListener>() == null)
                cameraObject.AddComponent<AudioListener>();
        }
        library = Resources.Load<DialogueSpriteLibrary>("Novel/SpriteLibrary");

        GameObject backgroundObject = new GameObject("Novel Background");
        backgroundObject.transform.SetParent(transform, false);
        background = backgroundObject.AddComponent<SpriteRenderer>();
        background.sortingOrder = -1000;
        background.enabled = false;

        SpriteRenderer existingCharacter = null;
        SpriteRenderer[] renderers = UnityEngine.Object.FindObjectsOfType<SpriteRenderer>(true);
        for (int i = 0; i < renderers.Length; i++)
        {
            if (renderers[i] == null) continue;
            if (string.Equals(renderers[i].gameObject.name.Trim(), "gg(char1)", StringComparison.OrdinalIgnoreCase))
            {
                existingCharacter = renderers[i];
                break;
            }
        }

        if (existingCharacter != null)
        {
            character = existingCharacter;
            character.sprite = null;
            character.enabled = false;
        }
        else
        {
            GameObject characterObject = new GameObject("Novel Character");
            characterObject.transform.SetParent(transform, false);
            character = characterObject.AddComponent<SpriteRenderer>();
        }
        character.sortingOrder = 0;
    }

    public void SetBackground(string key)
    {
        if (string.IsNullOrEmpty(key)) return;
        if (string.Equals(key, "none", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(key, "hide", StringComparison.OrdinalIgnoreCase))
        {
            currentBackground = null;
            if (background != null) background.enabled = false;
            return;
        }
        if (string.Equals(currentBackground, key, StringComparison.OrdinalIgnoreCase)) return;

        Sprite sprite = Resolve(key);
        if (sprite == null)
        {
            Debug.LogWarning("[Novel] Нет фона для ключа: " + key);
            return;
        }

        currentBackground = key;
        background.sprite = sprite;
        background.enabled = true;
        FitBackground(sprite);
    }

    public void SetCharacter(string key, string position)
    {
        if (string.IsNullOrEmpty(key)) return;
        if (string.Equals(key, "none", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(key, "hide", StringComparison.OrdinalIgnoreCase))
        {
            currentCharacter = null;
            character.sprite = null;
            character.enabled = false;
            return;
        }

        if (string.Equals(currentCharacter, key, StringComparison.OrdinalIgnoreCase)) return;

        Sprite sprite = Resolve(key);
        if (sprite == null)
        {
            Debug.LogWarning("[Novel] Нет спрайта персонажа для ключа: " + key);
            return;
        }

        currentCharacter = key;
        character.sprite = sprite;
        character.enabled = true;

        float height = sprite.bounds.size.y;
        float scale = height > 0.001f ? 6.6f / height : 1f;
        character.transform.localScale = new Vector3(scale, scale, 1f);

        float x = 0f;
        if (string.Equals(position, "left", StringComparison.OrdinalIgnoreCase)) x = -2.9f;
        else if (string.Equals(position, "right", StringComparison.OrdinalIgnoreCase)) x = 2.9f;
        else if (string.Equals(position, "farleft", StringComparison.OrdinalIgnoreCase)) x = -4.1f;
        else if (string.Equals(position, "farright", StringComparison.OrdinalIgnoreCase)) x = 4.1f;

        float halfHeight = sprite.bounds.size.y * scale * 0.5f;
        float bottom = viewCamera != null && viewCamera.orthographic
            ? viewCamera.transform.position.y - viewCamera.orthographicSize
            : -5f;
        character.transform.localPosition = new Vector3(x, bottom + halfHeight, 0f);
    }

    private void FitBackground(Sprite sprite)
    {
        if (viewCamera == null || sprite == null) return;

        float worldHeight = viewCamera.orthographic ? viewCamera.orthographicSize * 2f : 10f;
        float worldWidth = worldHeight * Mathf.Max(0.1f, viewCamera.aspect);
        Vector2 spriteSize = sprite.bounds.size;
        float scale = Mathf.Max(worldWidth / Mathf.Max(0.001f, spriteSize.x),
                                worldHeight / Mathf.Max(0.001f, spriteSize.y));

        Vector3 cameraPosition = viewCamera.transform.position;
        background.transform.localScale = new Vector3(scale, scale, 1f);
        background.transform.position = new Vector3(cameraPosition.x, cameraPosition.y, 0f);
    }

    private Sprite Resolve(string key)
    {
        if (library != null)
        {
            Sprite fromLibrary = library.Get(key);
            if (fromLibrary != null) return fromLibrary;
        }

        Sprite fromResources = Resources.Load<Sprite>("Novel/Sprites/" + key);
        if (fromResources != null) return fromResources;

        fromResources = Resources.Load<Sprite>("Novel/" + key);
        if (fromResources != null) return fromResources;

        return BuildPlaceholder(key);
    }

    private static Sprite BuildPlaceholder(string key)
    {
        Sprite cached;
        if (placeholderCache.TryGetValue(key, out cached)) return cached;

        int hash = 0;
        for (int i = 0; i < key.Length; i++) hash = hash * 31 + key[i];
        float hue = Mathf.Abs(hash % 360) / 360f;

        Color top = Color.HSVToRGB(hue, 0.28f, 0.34f);
        Color bottom = Color.HSVToRGB(hue, 0.22f, 0.12f);

        Texture2D texture = new Texture2D(8, 8, TextureFormat.RGBA32, false);
        texture.name = "NovelPlaceholder_" + key;
        texture.wrapMode = TextureWrapMode.Clamp;
        for (int y = 0; y < 8; y++)
        {
            Color row = Color.Lerp(bottom, top, y / 7f);
            for (int x = 0; x < 8; x++)
                texture.SetPixel(x, y, row);
        }
        texture.Apply();

        Sprite sprite = Sprite.Create(texture, new Rect(0f, 0f, 8f, 8f), new Vector2(0.5f, 0.5f), 1f);
        sprite.name = "NovelPlaceholder_" + key;
        placeholderCache[key] = sprite;
        return sprite;
    }
}
