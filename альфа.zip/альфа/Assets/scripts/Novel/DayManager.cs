using System.Collections;
using UnityEngine;

public class DayManager : MonoBehaviour
{
    private static readonly string[] Phases = { "morning", "afternoon", "night" };

    private NovelRuntime runtime;
    private DialogueRunner runner;
    private ScheduleDay currentDaySchedule;
    private string currentPhase;
    private bool transitioning;

    public void Init(NovelRuntime runtime, DialogueRunner runner)
    {
        this.runtime = runtime;
        this.runner = runner;
        DialogueLoader.LoadSchedule();
    }

    public void StartDay(int day)
    {
        transitioning = false;
        int actualDay = day;
        ScheduleDay schedule = DialogueLoader.FindDay(actualDay);

        if (!HasAnyPhase(schedule))
        {
            actualDay = FindNextDayWithContent(day + 1);
            if (actualDay < 0)
            {
                StartCoroutine(EndOfDemo());
                return;
            }
            schedule = DialogueLoader.FindDay(actualDay);
        }

        GameSession.SetDay(actualDay);
        currentDaySchedule = schedule;
        string phase = FirstPhase(currentDaySchedule);
        if (string.IsNullOrEmpty(phase))
        {
            StartCoroutine(SleepToNextDay());
            return;
        }

        StartPhase(phase);
    }

    public void OnDialogueEnded()
    {
        if (transitioning) return;

        string nextPhase;
        if (currentDaySchedule != null && TryNextPhase(currentPhase, out nextPhase))
        {
            StartPhase(nextPhase);
            return;
        }

        StartCoroutine(SleepToNextDay());
    }

    public void ResumeFromSave(SaveData data)
    {
        if (data == null) return;

        transitioning = false;
        GameSession.SetDay(data.day);
        currentDaySchedule = DialogueLoader.FindDay(GameSession.Day);
        currentPhase = null;

        if (currentDaySchedule != null && !string.IsNullOrEmpty(data.dialogueId))
        {
            for (int i = 0; i < Phases.Length; i++)
            {
                if (string.Equals(DialogueLoader.GetPhaseDialogue(currentDaySchedule, Phases[i]), data.dialogueId, System.StringComparison.OrdinalIgnoreCase))
                {
                    currentPhase = Phases[i];
                    break;
                }
            }
        }

        if (string.IsNullOrEmpty(currentPhase) && currentDaySchedule != null)
            currentPhase = FirstPhase(currentDaySchedule);
    }

    private void StartPhase(string phase)
    {
        transitioning = false;
        currentPhase = phase;

        string id = DialogueLoader.GetPhaseDialogue(currentDaySchedule, phase);
        if (string.IsNullOrEmpty(id))
        {
            StartCoroutine(SleepToNextDay());
            return;
        }

        bool started = runner.StartDialogue(id);
        if (started)
        {
            if (runtime != null) runtime.SaveAuto();
        }
        else
        {
            StartCoroutine(SleepToNextDay());
        }
    }

    private IEnumerator SleepToNextDay()
    {
        if (transitioning) yield break;
        transitioning = true;

        if (runtime != null && runtime.UI != null)
            yield return runtime.UI.FadeTo(1f, 0.6f);

        int nextDay = FindNextDayWithContent(GameSession.Day + 1);
        if (nextDay < 0)
        {
            yield return EndOfDemo();
            yield break;
        }

        GameSession.SetDay(nextDay);
        currentDaySchedule = DialogueLoader.FindDay(nextDay);
        string phase = FirstPhase(currentDaySchedule);
        if (string.IsNullOrEmpty(phase))
        {
            yield return EndOfDemo();
            yield break;
        }

        StartPhase(phase);
        if (runtime != null && runtime.UI != null)
            yield return runtime.UI.FadeTo(0f, 0.6f);
        transitioning = false;
    }

    private IEnumerator EndOfDemo()
    {
        transitioning = true;

        if (runtime != null && runtime.UI != null)
        {
            yield return runtime.UI.FadeTo(1f, 0.7f);
            runtime.UI.ShowToast("Конец демо", 2.5f);
        }

        yield return new WaitForSecondsRealtime(1.8f);

        if (runtime != null) runtime.ReturnToMenu(false);
        transitioning = false;
    }

    private string FirstPhase(ScheduleDay schedule)
    {
        if (schedule == null) return null;
        for (int i = 0; i < Phases.Length; i++)
        {
            if (DialogueLoader.HasPhase(schedule, Phases[i]))
                return Phases[i];
        }
        return null;
    }

    private bool TryNextPhase(string phase, out string nextPhase)
    {
        nextPhase = null;
        if (currentDaySchedule == null) return false;

        int start = 0;
        for (int i = 0; i < Phases.Length; i++)
        {
            if (string.Equals(Phases[i], phase, System.StringComparison.OrdinalIgnoreCase))
            {
                start = i + 1;
                break;
            }
        }

        for (int i = start; i < Phases.Length; i++)
        {
            if (DialogueLoader.HasPhase(currentDaySchedule, Phases[i]))
            {
                nextPhase = Phases[i];
                return true;
            }
        }
        return false;
    }

    private bool HasAnyPhase(ScheduleDay schedule)
    {
        if (schedule == null) return false;
        for (int i = 0; i < Phases.Length; i++)
        {
            if (DialogueLoader.HasPhase(schedule, Phases[i]))
                return true;
        }
        return false;
    }

    private int FindNextDayWithContent(int startDay)
    {
        for (int day = startDay; day <= startDay + 60; day++)
        {
            ScheduleDay schedule = DialogueLoader.FindDay(day);
            if (HasAnyPhase(schedule)) return day;
        }
        return -1;
    }
}
