using System.Text;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class BacklogUI : MonoBehaviour
{
    private NovelRuntime runtime;
    private GameObject root;
    private ScrollRect scroll;
    private TMP_Text content;
    private RectTransform contentRect;

    public bool IsOpen
    {
        get { return root != null && root.activeSelf; }
    }

    public void Init(NovelRuntime runtime)
    {
        this.runtime = runtime;
        Build();
    }

    private void Build()
    {
        GameObject canvasObject = new GameObject("Novel Backlog Canvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        canvasObject.transform.SetParent(transform, false);
        Canvas canvas = canvasObject.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvas.sortingOrder = 150;
        CanvasScaler scaler = canvasObject.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1280f, 720f);
        scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        scaler.matchWidthOrHeight = 0.5f;

        root = new GameObject("Backlog Root", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        root.transform.SetParent(canvasObject.transform, false);
        Stretch(root.GetComponent<RectTransform>());
        Image backdrop = root.GetComponent<Image>();
        backdrop.color = new Color(0f, 0f, 0f, 0.88f);
        backdrop.raycastTarget = true;

        GameObject panel = new GameObject("Backlog Panel", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        panel.transform.SetParent(root.transform, false);
        RectTransform panelRect = panel.GetComponent<RectTransform>();
        panelRect.anchorMin = new Vector2(0.08f, 0.08f);
        panelRect.anchorMax = new Vector2(0.92f, 0.92f);
        panelRect.offsetMin = Vector2.zero;
        panelRect.offsetMax = Vector2.zero;
        panel.GetComponent<Image>().color = new Color(0.04f, 0.05f, 0.08f, 0.98f);

        TMP_Text title = CreateText("Backlog Title", panel.transform, "ИСТОРИЯ", 28f, new Color(1f, 0.88f, 0.68f, 1f));
        RectTransform titleRect = title.rectTransform;
        titleRect.anchorMin = new Vector2(0.05f, 0.9f);
        titleRect.anchorMax = new Vector2(0.7f, 0.98f);
        titleRect.offsetMin = Vector2.zero;
        titleRect.offsetMax = Vector2.zero;
        title.alignment = TextAlignmentOptions.Left;
        title.fontStyle = FontStyles.Bold;

        GameObject scrollObject = new GameObject("Scroll", typeof(RectTransform), typeof(ScrollRect));
        scrollObject.transform.SetParent(panel.transform, false);
        RectTransform scrollRect = scrollObject.GetComponent<RectTransform>();
        scrollRect.anchorMin = new Vector2(0.05f, 0.1f);
        scrollRect.anchorMax = new Vector2(0.95f, 0.88f);
        scrollRect.offsetMin = Vector2.zero;
        scrollRect.offsetMax = Vector2.zero;
        scroll = scrollObject.GetComponent<ScrollRect>();
        scroll.horizontal = false;
        scroll.vertical = true;
        scroll.movementType = ScrollRect.MovementType.Clamped;
        scroll.scrollSensitivity = 30f;

        GameObject viewportObject = new GameObject("Viewport", typeof(RectTransform), typeof(RectMask2D));
        viewportObject.transform.SetParent(scrollObject.transform, false);
        RectTransform viewportRect = viewportObject.GetComponent<RectTransform>();
        Stretch(viewportRect);
        scroll.viewport = viewportRect;

        content = CreateText("Content", viewportObject.transform, string.Empty, 22f, Color.white);
        contentRect = content.rectTransform;
        contentRect.anchorMin = new Vector2(0f, 1f);
        contentRect.anchorMax = new Vector2(1f, 1f);
        contentRect.pivot = new Vector2(0.5f, 1f);
        contentRect.offsetMin = new Vector2(12f, 0f);
        contentRect.offsetMax = new Vector2(-12f, 0f);
        content.alignment = TextAlignmentOptions.TopLeft;
        content.enableWordWrapping = true;
        content.lineSpacing = 4f;
        ContentSizeFitter fitter = content.gameObject.AddComponent<ContentSizeFitter>();
        fitter.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
        fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
        scroll.content = contentRect;

        Button closeButton = CreateButton(panel.transform, "Закрыть", delegate { Close(); });
        RectTransform closeRect = closeButton.GetComponent<RectTransform>();
        closeRect.anchorMin = new Vector2(0.76f, 0.9f);
        closeRect.anchorMax = new Vector2(0.95f, 0.98f);
        closeRect.offsetMin = Vector2.zero;
        closeRect.offsetMax = Vector2.zero;

        root.SetActive(false);
    }

    public void Toggle()
    {
        if (IsOpen) Close();
        else Open();
    }

    public void Open()
    {
        if (root == null) return;
        root.SetActive(true);
        BuildContent();
        Canvas.ForceUpdateCanvases();
        LayoutRebuilder.ForceRebuildLayoutImmediate(contentRect);
        if (scroll != null) scroll.verticalNormalizedPosition = 0f;
        if (runtime != null && runtime.Runner != null) runtime.Runner.NotifyModalClosed();
    }

    public void Close()
    {
        if (root == null) return;
        root.SetActive(false);
        if (runtime != null && runtime.Runner != null) runtime.Runner.NotifyModalClosed();
    }

    private void BuildContent()
    {
        if (content == null) return;
        if (GameSession.History.Count == 0)
        {
            content.text = "Пока пусто.";
            return;
        }

        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < GameSession.History.Count; i++)
        {
            if (i > 0) builder.Append("\n\n");
            builder.Append(GameSession.History[i]);
        }
        content.text = builder.ToString();
    }

    private Button CreateButton(Transform parent, string text, UnityEngine.Events.UnityAction action)
    {
        GameObject buttonObject = new GameObject(text, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(Button));
        buttonObject.transform.SetParent(parent, false);
        Image image = buttonObject.GetComponent<Image>();
        image.color = new Color(0.14f, 0.17f, 0.23f, 1f);
        Button button = buttonObject.GetComponent<Button>();
        button.targetGraphic = image;
        Navigation navigation = new Navigation();
        navigation.mode = Navigation.Mode.None;
        button.navigation = navigation;

        TextMeshProUGUI label = CreateText("Label", buttonObject.transform, text, 20f, Color.white);
        Stretch(label.rectTransform);
        label.alignment = TextAlignmentOptions.Center;
        button.onClick.AddListener(action);
        return button;
    }

    private TextMeshProUGUI CreateText(string name, Transform parent, string text, float size, Color color)
    {
        GameObject textObject = new GameObject(name, typeof(RectTransform));
        textObject.transform.SetParent(parent, false);
        TextMeshProUGUI component = textObject.AddComponent<TextMeshProUGUI>();
        component.text = text;
        component.fontSize = size;
        component.color = color;
        component.enableWordWrapping = true;
        component.raycastTarget = false;
        TMP_FontAsset font = runtime != null && runtime.UI != null ? runtime.UI.Font : null;
        if (font == null) font = TMP_Settings.defaultFontAsset;
        if (font != null) component.font = font;
        return component;
    }

    private static void Stretch(RectTransform rect)
    {
        rect.anchorMin = Vector2.zero;
        rect.anchorMax = Vector2.one;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
    }
}
