using System;
using System.Collections.Generic;
using UnityEngine;

public static class DialogueLoader
{
    private static readonly Dictionary<string, DialogueFile> cache =
        new Dictionary<string, DialogueFile>(StringComparer.OrdinalIgnoreCase);
    private static ScheduleFile schedule;

    public static void ClearCache()
    {
        cache.Clear();
        schedule = null;
    }

    public static DialogueFile Load(string id)
    {
        if (string.IsNullOrEmpty(id)) return null;

        DialogueFile cached;
        if (cache.TryGetValue(id, out cached)) return cached;

        TextAsset asset = Resources.Load<TextAsset>("Dialogues/" + id);
        if (asset == null)
        {
            Debug.LogError("[Novel] Не найден диалог Resources/Dialogues/" + id + ".json");
            return null;
        }

        DialogueFile file = null;
        try
        {
            file = JsonUtility.FromJson<DialogueFile>(TrimBom(asset.text));
        }
        catch (Exception exception)
        {
            Debug.LogError("[Novel] Ошибка JSON в диалоге " + id + ": " + exception.Message);
            return null;
        }

        if (file == null)
        {
            Debug.LogError("[Novel] Пустой диалог: " + id);
            return null;
        }

        if (string.IsNullOrEmpty(file.id)) file.id = id;
        if (file.nodes == null) file.nodes = new List<DialogueNode>();
        file.map = new Dictionary<string, DialogueNode>(StringComparer.OrdinalIgnoreCase);

        for (int i = 0; i < file.nodes.Count; i++)
        {
            DialogueNode node = file.nodes[i];
            if (node == null || string.IsNullOrEmpty(node.id))
            {
                Debug.LogWarning("[Novel] В диалоге " + id + " узел без id пропущен.");
                continue;
            }
            node.file = file;
            if (node.effects == null) node.effects = new List<string>();
            if (node.choices == null) node.choices = new List<DialogueChoice>();
            for (int c = 0; c < node.choices.Count; c++)
            {
                if (node.choices[c] == null)
                {
                    node.choices.RemoveAt(c);
                    c--;
                    continue;
                }
                if (node.choices[c].effects == null) node.choices[c].effects = new List<string>();
            }

            if (file.map.ContainsKey(node.id))
                Debug.LogWarning("[Novel] Дублирующийся id узла в " + id + ": " + node.id);
            else
                file.map[node.id] = node;
        }

        if (string.IsNullOrEmpty(file.start) && file.nodes.Count > 0)
            file.start = file.nodes[0].id;

        if (!string.IsNullOrEmpty(file.start) && !file.map.ContainsKey(file.start))
            Debug.LogError("[Novel] Стартовый узел не найден в " + id + ": " + file.start);

        Validate(file);
        cache[id] = file;
        return file;
    }

    public static DialogueNode GetNode(DialogueFile file, string nodeId)
    {
        if (file == null || file.map == null || string.IsNullOrEmpty(nodeId)) return null;
        DialogueNode node;
        return file.map.TryGetValue(nodeId, out node) ? node : null;
    }

    public static ScheduleFile LoadSchedule()
    {
        if (schedule != null) return schedule;

        TextAsset asset = Resources.Load<TextAsset>("Dialogues/schedule");
        if (asset == null)
        {
            Debug.LogError("[Novel] Не найден Resources/Dialogues/schedule.json");
            schedule = new ScheduleFile();
            return schedule;
        }

        try
        {
            schedule = JsonUtility.FromJson<ScheduleFile>(TrimBom(asset.text));
        }
        catch (Exception exception)
        {
            Debug.LogError("[Novel] Ошибка JSON в schedule.json: " + exception.Message);
            schedule = new ScheduleFile();
        }

        if (schedule == null) schedule = new ScheduleFile();
        if (schedule.days == null) schedule.days = new List<ScheduleDay>();
        schedule.days.Sort(CompareSchedules);
        return schedule;
    }

    public static ScheduleDay FindDay(int day)
    {
        ScheduleFile data = LoadSchedule();
        for (int i = 0; i < data.days.Count; i++)
        {
            if (data.days[i] != null && data.days[i].day == day) return data.days[i];
        }
        return null;
    }

    public static string GetPhaseDialogue(ScheduleDay day, string phase)
    {
        if (day == null || string.IsNullOrEmpty(phase)) return null;
        switch (phase)
        {
            case "morning": return day.morning;
            case "afternoon": return day.afternoon;
            case "night": return day.night;
            default: return null;
        }
    }

    public static bool HasPhase(ScheduleDay day, string phase)
    {
        return !string.IsNullOrEmpty(GetPhaseDialogue(day, phase));
    }

    private static void Validate(DialogueFile file)
    {
        for (int i = 0; i < file.nodes.Count; i++)
        {
            DialogueNode node = file.nodes[i];
            if (node == null) continue;
            if (!string.IsNullOrEmpty(node.next) && !file.map.ContainsKey(node.next))
                Debug.LogWarning("[Novel] " + file.id + "/" + node.id + ": next не найден -> " + node.next);
            if (!string.IsNullOrEmpty(node.elseNext) && !file.map.ContainsKey(node.elseNext))
                Debug.LogWarning("[Novel] " + file.id + "/" + node.id + ": elseNext не найден -> " + node.elseNext);
            for (int c = 0; c < node.choices.Count; c++)
            {
                DialogueChoice choice = node.choices[c];
                if (choice == null) continue;
                if (!string.IsNullOrEmpty(choice.next) && !file.map.ContainsKey(choice.next))
                    Debug.LogWarning("[Novel] " + file.id + "/" + node.id + ": выбор ведёт в несуществующий узел -> " + choice.next);
            }
        }
    }

    private static int CompareSchedules(ScheduleDay left, ScheduleDay right)
    {
        if (left == null && right == null) return 0;
        if (left == null) return -1;
        if (right == null) return 1;
        return left.day.CompareTo(right.day);
    }

    private static string TrimBom(string text)
    {
        if (string.IsNullOrEmpty(text)) return text;
        return text.TrimStart('\uFEFF');
    }
}
