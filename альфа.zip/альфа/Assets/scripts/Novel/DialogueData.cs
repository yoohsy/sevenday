using System;
using System.Collections.Generic;

[Serializable]
public class DialogueChoice
{
    public string text;
    public string next;
    public string condition;
    public List<string> effects = new List<string>();
}

[Serializable]
public class DialogueNode
{
    public string id;
    public string speaker;
    public string text;
    public string background;
    public string sprite;
    public string characterPosition;
    public string condition;
    public List<string> effects = new List<string>();
    public string next;
    public string elseNext;
    public List<DialogueChoice> choices = new List<DialogueChoice>();
    public bool end;
    public string nextScene;

    [NonSerialized] public DialogueFile file;
}

[Serializable]
public class DialogueFile
{
    public string id;
    public string start;
    public List<DialogueNode> nodes = new List<DialogueNode>();

    [NonSerialized] public Dictionary<string, DialogueNode> map;
}

[Serializable]
public class ScheduleDay
{
    public int day;
    public string morning;
    public string afternoon;
    public string night;
}

[Serializable]
public class ScheduleFile
{
    public List<ScheduleDay> days = new List<ScheduleDay>();
}
