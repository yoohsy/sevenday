using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class PauseMenuUI : MonoBehaviour
{
    private NovelRuntime runtime;
    private GameObject root;
    private GameObject slotPanel;
    private TMP_Text slotTitle;
    private readonly Button[] slotButtons = new Button[SaveSystem.SlotCount + 1];
    private readonly TMP_Text[] slotLabels = new TMP_Text[SaveSystem.SlotCount + 1];
    private bool saveMode;
    private GameObject toastRoot;
    private CanvasGroup toastGroup;
    private TMP_Text toastText;
    private Coroutine toastRoutine;

    public bool IsOpen
    {
        get { return root != null && root.activeSelf; }
    }

    public void Init(NovelRuntime runtime)
    {
        this.runtime = runtime;
        Build();
    }

    private void Build()
    {
        GameObject canvasObject = new GameObject("Novel Pause Canvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        canvasObject.transform.SetParent(transform, false);
        Canvas canvas = canvasObject.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvas.sortingOrder = 200;
        CanvasScaler scaler = canvasObject.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1280f, 720f);
        scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        scaler.matchWidthOrHeight = 0.5f;

        root = new GameObject("Pause Root", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        root.transform.SetParent(canvasObject.transform, false);
        Stretch(root.GetComponent<RectTransform>());
        Image backdrop = root.GetComponent<Image>();
        backdrop.color = new Color(0f, 0f, 0f, 0.78f);
        backdrop.raycastTarget = true;

        GameObject panel = new GameObject("Pause Panel", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        panel.transform.SetParent(root.transform, false);
        RectTransform panelRect = panel.GetComponent<RectTransform>();
        panelRect.anchorMin = new Vector2(0.5f, 0.5f);
        panelRect.anchorMax = new Vector2(0.5f, 0.5f);
        panelRect.pivot = new Vector2(0.5f, 0.5f);
        panelRect.sizeDelta = new Vector2(560f, 520f);
        Image panelImage = panel.GetComponent<Image>();
        panelImage.color = new Color(0.05f, 0.06f, 0.09f, 0.98f);

        TMP_Text title = CreateText("Title", panel.transform, "ПАУЗА", 34f, new Color(1f, 0.88f, 0.68f, 1f));
        RectTransform titleRect = title.rectTransform;
        titleRect.anchorMin = new Vector2(0.1f, 0.84f);
        titleRect.anchorMax = new Vector2(0.9f, 0.96f);
        titleRect.offsetMin = Vector2.zero;
        titleRect.offsetMax = Vector2.zero;
        title.alignment = TextAlignmentOptions.Center;
        title.fontStyle = FontStyles.Bold;

        GameObject buttonsRoot = new GameObject("Buttons", typeof(RectTransform), typeof(VerticalLayoutGroup));
        buttonsRoot.transform.SetParent(panel.transform, false);
        RectTransform buttonsRect = buttonsRoot.GetComponent<RectTransform>();
        buttonsRect.anchorMin = new Vector2(0.14f, 0.12f);
        buttonsRect.anchorMax = new Vector2(0.86f, 0.8f);
        buttonsRect.offsetMin = Vector2.zero;
        buttonsRect.offsetMax = Vector2.zero;
        VerticalLayoutGroup layout = buttonsRoot.GetComponent<VerticalLayoutGroup>();
        layout.spacing = 9f;
        layout.childAlignment = TextAnchor.MiddleCenter;
        layout.childControlWidth = true;
        layout.childControlHeight = true;
        layout.childForceExpandWidth = true;
        layout.childForceExpandHeight = false;

        CreateButton(buttonsRoot.transform, "Продолжить", 52f, Close);
        CreateButton(buttonsRoot.transform, "Сохранить", 52f, delegate { OpenSlots(true); });
        CreateButton(buttonsRoot.transform, "Загрузить", 52f, delegate { OpenSlots(false); });
        CreateButton(buttonsRoot.transform, "В главное меню", 52f, delegate { runtime.ReturnToMenu(true); });
        CreateButton(buttonsRoot.transform, "Выход", 52f, QuitGame);

        BuildSlotPanel(root.transform);
        BuildToast(root.transform);

        root.SetActive(false);
    }

    private void BuildSlotPanel(Transform parent)
    {
        slotPanel = new GameObject("Slots Panel", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        slotPanel.transform.SetParent(parent, false);
        Stretch(slotPanel.GetComponent<RectTransform>());
        Image backdrop = slotPanel.GetComponent<Image>();
        backdrop.color = new Color(0f, 0f, 0f, 0.88f);
        backdrop.raycastTarget = true;

        GameObject panel = new GameObject("Slots List", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        panel.transform.SetParent(slotPanel.transform, false);
        RectTransform panelRect = panel.GetComponent<RectTransform>();
        panelRect.anchorMin = new Vector2(0.5f, 0.5f);
        panelRect.anchorMax = new Vector2(0.5f, 0.5f);
        panelRect.pivot = new Vector2(0.5f, 0.5f);
        panelRect.sizeDelta = new Vector2(760f, 660f);
        panel.GetComponent<Image>().color = new Color(0.05f, 0.06f, 0.09f, 0.98f);

        slotTitle = CreateText("Slots Title", panel.transform, "Сохранение", 30f, new Color(1f, 0.88f, 0.68f, 1f));
        RectTransform slotTitleRect = slotTitle.rectTransform;
        slotTitleRect.anchorMin = new Vector2(0.1f, 0.91f);
        slotTitleRect.anchorMax = new Vector2(0.9f, 0.98f);
        slotTitleRect.offsetMin = Vector2.zero;
        slotTitleRect.offsetMax = Vector2.zero;
        slotTitle.alignment = TextAlignmentOptions.Center;
        slotTitle.fontStyle = FontStyles.Bold;

        GameObject listRoot = new GameObject("Slot Buttons", typeof(RectTransform), typeof(VerticalLayoutGroup));
        listRoot.transform.SetParent(panel.transform, false);
        RectTransform listRect = listRoot.GetComponent<RectTransform>();
        listRect.anchorMin = new Vector2(0.06f, 0.13f);
        listRect.anchorMax = new Vector2(0.94f, 0.9f);
        listRect.offsetMin = Vector2.zero;
        listRect.offsetMax = Vector2.zero;
        VerticalLayoutGroup layout = listRoot.GetComponent<VerticalLayoutGroup>();
        layout.spacing = 3f;
        layout.childAlignment = TextAnchor.UpperCenter;
        layout.childControlWidth = true;
        layout.childControlHeight = true;
        layout.childForceExpandWidth = true;
        layout.childForceExpandHeight = false;

        for (int slot = 1; slot <= SaveSystem.SlotCount; slot++)
        {
            int captured = slot;
            Button button = CreateButton(listRoot.transform, "Слот " + slot, 44f, delegate { OnSlotClicked(captured); });
            button.gameObject.name = "Pause Slot " + slot;
            slotButtons[slot] = button;
            TMP_Text label = button.GetComponentInChildren<TMP_Text>(true);
            slotLabels[slot] = label;
            if (label != null)
            {
                label.fontSize = 19f;
                label.alignment = TextAlignmentOptions.Left;
            }
        }

        CreateButton(panel.transform, "Назад", 44f, delegate { slotPanel.SetActive(false); }).gameObject.name = "Slots Back";
        Button back = panel.transform.Find("Slots Back").GetComponent<Button>();
        RectTransform backRect = back.GetComponent<RectTransform>();
        backRect.anchorMin = new Vector2(0.32f, 0.03f);
        backRect.anchorMax = new Vector2(0.68f, 0.1f);
        backRect.offsetMin = Vector2.zero;
        backRect.offsetMax = Vector2.zero;
        LayoutElement backLayout = back.GetComponent<LayoutElement>();
        if (backLayout != null) Destroy(backLayout);

        slotPanel.SetActive(false);
    }

    private void BuildToast(Transform parent)
    {
        toastRoot = new GameObject("Pause Toast", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(CanvasGroup));
        toastRoot.transform.SetParent(parent, false);
        RectTransform rect = toastRoot.GetComponent<RectTransform>();
        rect.anchorMin = new Vector2(0.3f, 0.06f);
        rect.anchorMax = new Vector2(0.7f, 0.12f);
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
        Image image = toastRoot.GetComponent<Image>();
        image.color = new Color(0f, 0f, 0f, 0.75f);
        image.raycastTarget = false;
        toastGroup = toastRoot.GetComponent<CanvasGroup>();
        toastGroup.alpha = 0f;
        toastGroup.blocksRaycasts = false;

        toastText = CreateText("Toast Text", toastRoot.transform, string.Empty, 20f, Color.white);
        Stretch(toastText.rectTransform);
        toastText.alignment = TextAlignmentOptions.Center;
        toastText.raycastTarget = false;
    }

    private void OnSlotClicked(int slot)
    {
        if (runtime == null) return;

        if (saveMode)
        {
            if (runtime.SaveGame(slot))
            {
                RefreshSlots();
                ShowToast("Сохранено в слот " + slot);
            }
            else
            {
                ShowToast("Не удалось сохранить");
            }
            return;
        }

        SaveData data;
        if (!SaveSystem.TryLoad(slot, out data))
        {
            ShowToast("Слот пуст");
            return;
        }

        Close();
        runtime.LoadGame(slot);
    }

    public void Toggle()
    {
        if (IsOpen) Close();
        else Open();
    }

    public void Open()
    {
        if (root == null) return;
        root.SetActive(true);
        if (slotPanel != null) slotPanel.SetActive(false);
        if (runtime != null && runtime.Runner != null) runtime.Runner.NotifyModalClosed();
    }

    public void Close()
    {
        if (root == null) return;
        root.SetActive(false);
        if (slotPanel != null) slotPanel.SetActive(false);
        if (runtime != null && runtime.Runner != null) runtime.Runner.NotifyModalClosed();
    }

    private void OpenSlots(bool save)
    {
        saveMode = save;
        if (slotTitle != null) slotTitle.text = save ? "Сохранить в слот" : "Загрузить слот";
        RefreshSlots();
        if (slotPanel != null) slotPanel.SetActive(true);
    }

    private void RefreshSlots()
    {
        for (int slot = 1; slot <= SaveSystem.SlotCount; slot++)
        {
            SaveData data = SaveSystem.Peek(slot);
            TMP_Text label = slotLabels[slot];
            if (label != null)
            {
                label.text = data != null
                    ? "Слот " + slot + "   ·   День " + data.day + "   ·   " + SaveSystem.FormatDate(data)
                    : "Слот " + slot + "   ·   пусто";
            }
            if (slotButtons[slot] != null)
                slotButtons[slot].interactable = saveMode || data != null;
        }
    }

    private void ShowToast(string text)
    {
        if (toastText == null) return;
        toastText.text = text;
        if (toastRoutine != null) StopCoroutine(toastRoutine);
        toastRoutine = StartCoroutine(ToastRoutine());
    }

    private IEnumerator ToastRoutine()
    {
        if (toastGroup != null) toastGroup.alpha = 1f;
        yield return new WaitForSecondsRealtime(1.5f);
        float elapsed = 0f;
        while (elapsed < 0.3f)
        {
            elapsed += Time.unscaledDeltaTime;
            if (toastGroup != null) toastGroup.alpha = 1f - Mathf.Clamp01(elapsed / 0.3f);
            yield return null;
        }
        if (toastGroup != null) toastGroup.alpha = 0f;
        toastRoutine = null;
    }

    private Button CreateButton(Transform parent, string text, float height, UnityAction action)
    {
        GameObject buttonObject = new GameObject(text, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(Button), typeof(LayoutElement));
        buttonObject.transform.SetParent(parent, false);

        Image image = buttonObject.GetComponent<Image>();
        image.color = new Color(0.14f, 0.17f, 0.23f, 1f);

        Button button = buttonObject.GetComponent<Button>();
        button.targetGraphic = image;
        button.transition = Selectable.Transition.ColorTint;
        ColorBlock colors = button.colors;
        colors.normalColor = Color.white;
        colors.highlightedColor = new Color(0.62f, 0.8f, 1f, 1f);
        colors.pressedColor = new Color(0.5f, 0.68f, 0.9f, 1f);
        colors.selectedColor = Color.white;
        colors.disabledColor = new Color(0.45f, 0.45f, 0.45f, 0.5f);
        colors.fadeDuration = 0.08f;
        button.colors = colors;
        Navigation navigation = new Navigation();
        navigation.mode = Navigation.Mode.None;
        button.navigation = navigation;

        LayoutElement layout = buttonObject.GetComponent<LayoutElement>();
        layout.minHeight = height;
        layout.preferredHeight = height;
        layout.flexibleHeight = 0f;

        TextMeshProUGUI label = CreateText("Label", buttonObject.transform, text, 22f, Color.white);
        Stretch(label.rectTransform);
        label.alignment = TextAlignmentOptions.Center;
        label.raycastTarget = false;

        if (action != null) button.onClick.AddListener(action);
        return button;
    }

    private TextMeshProUGUI CreateText(string name, Transform parent, string text, float size, Color color)
    {
        GameObject textObject = new GameObject(name, typeof(RectTransform));
        textObject.transform.SetParent(parent, false);
        TextMeshProUGUI component = textObject.AddComponent<TextMeshProUGUI>();
        component.text = text;
        component.fontSize = size;
        component.color = color;
        component.enableWordWrapping = true;
        component.raycastTarget = false;
        TMP_FontAsset font = runtime != null && runtime.UI != null ? runtime.UI.Font : null;
        if (font == null) font = TMP_Settings.defaultFontAsset;
        if (font != null) component.font = font;
        return component;
    }

    private static void Stretch(RectTransform rect)
    {
        rect.anchorMin = Vector2.zero;
        rect.anchorMax = Vector2.one;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
    }

    private static void QuitGame()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }
}
