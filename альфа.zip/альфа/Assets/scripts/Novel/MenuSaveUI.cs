using System;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MenuSaveUI : MonoBehaviour
{
    private GameObject continuePanel;
    private Button loadButton;
    private readonly Button[] slotButtons = new Button[SaveSystem.SlotCount + 1];
    private readonly Graphic[] slotLabelGraphics = new Graphic[SaveSystem.SlotCount + 1];
    private int selectedSlot = -1;
    private bool initializedSelection;
    private float nextRefresh;

    private void Start()
    {
        Setup();
    }

    private void Setup()
    {
        Transform panel = FindDeep("menu continue");
        if (panel != null) continuePanel = panel.gameObject;
        if (continuePanel == null)
        {
            Debug.LogWarning("[Novel] Не найдена панель 'menu continue'.");
            return;
        }

        for (int slot = 1; slot <= SaveSystem.SlotCount; slot++)
        {
            Transform slotTransform = FindChild(continuePanel.transform, "slot " + slot);
            if (slotTransform == null) continue;

            Button button = ResolveButton(slotTransform);
            slotButtons[slot] = button;

            Text legacyLabel = slotTransform.GetComponentInChildren<Text>(true);
            if (legacyLabel != null) slotLabelGraphics[slot] = legacyLabel;
            else slotLabelGraphics[slot] = slotTransform.GetComponentInChildren<TMP_Text>(true);

            if (button != null)
            {
                int captured = slot;
                button.onClick.AddListener(delegate { SelectSlot(captured); });
            }
        }

        Transform loadTransform = FindChild(continuePanel.transform, "load button");
        if (loadTransform == null) loadTransform = FindDeep("load button");
        if (loadTransform != null)
        {
            loadButton = ResolveButton(loadTransform);
            if (loadButton != null) loadButton.onClick.AddListener(LoadSelected);
        }

        Transform exitTransform = FindDeep("exit");
        if (exitTransform != null)
        {
            Button exitButton = ResolveButton(exitTransform);
            if (exitButton != null) exitButton.onClick.AddListener(QuitGame);
        }

        Transform newGameTransform = FindDeep("new game");
        if (newGameTransform != null)
        {
            Button newGameButton = ResolveButton(newGameTransform);
            if (newGameButton != null) newGameButton.onClick.AddListener(NewGame);
        }

        RefreshLabels();
        SelectLatest();
    }

    private void Update()
    {
        if (continuePanel == null) return;
        if (!continuePanel.activeInHierarchy) return;

        if (!initializedSelection)
        {
            initializedSelection = true;
            SelectLatest();
        }

        if (Time.unscaledTime < nextRefresh) return;
        nextRefresh = Time.unscaledTime + 0.5f;
        RefreshLabels();
        ApplySelectionColors();
    }

    private void RefreshLabels()
    {
        bool anySave = false;

        for (int slot = 1; slot <= SaveSystem.SlotCount; slot++)
        {
            SaveData data = SaveSystem.Peek(slot);
            bool hasSave = data != null;
            if (hasSave) anySave = true;

            Transform slotTransform = slotButtons[slot] != null ? slotButtons[slot].transform : null;
            if (slotTransform != null)
                SetLabel(slotTransform, hasSave
                    ? "Сохранение " + slot + " · Д" + data.day
                    : "Сохранение " + slot + " — пусто");

            if (slotButtons[slot] != null)
                slotButtons[slot].interactable = hasSave;
        }

        if (selectedSlot >= 1 && selectedSlot <= SaveSystem.SlotCount && !SaveSystem.HasSave(selectedSlot))
            selectedSlot = -1;

        if (loadButton != null)
        {
            SaveData latest;
            int slot = SaveSystem.FindLatestSlot(out latest);
            loadButton.interactable = slot >= 0 || anySave;
        }
    }

    private void SelectSlot(int slot)
    {
        if (!SaveSystem.HasSave(slot)) return;
        selectedSlot = slot;
        ApplySelectionColors();
    }

    private void SelectLatest()
    {
        SaveData data;
        int slot = SaveSystem.FindLatestManualSlot(out data);
        selectedSlot = slot;
        ApplySelectionColors();
    }

    private void ApplySelectionColors()
    {
        for (int slot = 1; slot <= SaveSystem.SlotCount; slot++)
        {
            if (slotLabelGraphics[slot] == null) continue;
            slotLabelGraphics[slot].color = slot == selectedSlot
                ? new Color(1f, 0.82f, 0.42f, 1f)
                : Color.white;
        }
    }

    private void LoadSelected()
    {
        int slot = selectedSlot;
        SaveData data;

        if (slot < 1 || !SaveSystem.TryLoad(slot, out data))
        {
            slot = SaveSystem.FindLatestSlot(out data);
            if (slot < 0 || data == null) return;
        }

        NovelLaunch.PendingSave = data;
        string scene = string.IsNullOrEmpty(data.sceneName) ? "cats" : data.sceneName;
        if (string.Equals(scene, "menu", StringComparison.OrdinalIgnoreCase)) scene = "cats";
        if (!Application.CanStreamedLevelBeLoaded(scene)) scene = "cats";
        SceneManager.LoadScene(scene);
    }

    private void NewGame()
    {
        NovelLaunch.PendingSave = null;
        NovelLaunch.NewGameRequested = true;
        if (UnityEngine.Object.FindObjectOfType<menu_navigation>() == null)
            SceneManager.LoadScene("cats");
    }

    private static void SetLabel(Transform slotTransform, string text)
    {
        Text legacy = slotTransform.GetComponentInChildren<Text>(true);
        if (legacy != null)
        {
            legacy.text = text;
            return;
        }

        TMP_Text tmp = slotTransform.GetComponentInChildren<TMP_Text>(true);
        if (tmp != null) tmp.text = text;
    }

    private static Transform FindChild(Transform root, string name)
    {
        Transform[] children = root.GetComponentsInChildren<Transform>(true);
        for (int i = 0; i < children.Length; i++)
        {
            if (children[i] == null) continue;
            if (string.Equals(children[i].name.Trim(), name, StringComparison.OrdinalIgnoreCase))
                return children[i];
        }
        return null;
    }

    private static Transform FindDeep(string name)
    {
        Transform[] transforms = UnityEngine.Object.FindObjectsOfType<Transform>(true);
        for (int i = 0; i < transforms.Length; i++)
        {
            if (transforms[i] == null) continue;
            if (string.Equals(transforms[i].name.Trim(), name, StringComparison.OrdinalIgnoreCase))
                return transforms[i];
        }
        return null;
    }

    private static Button ResolveButton(Transform target)
    {
        if (target == null) return null;
        Button button = target.GetComponent<Button>();
        if (button == null) button = target.GetComponentInParent<Button>();
        if (button == null) button = target.GetComponentInChildren<Button>(true);
        return button;
    }

    private static void QuitGame()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }
}
