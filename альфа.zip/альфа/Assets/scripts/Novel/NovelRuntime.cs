using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

public static class NovelLaunch
{
    public static SaveData PendingSave;
    public static bool NewGameRequested;
}

public static class NovelBootstrap
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void CreateWatcher()
    {
        NovelLaunch.PendingSave = null;
        NovelLaunch.NewGameRequested = false;
        if (UnityEngine.Object.FindObjectOfType<NovelSceneWatcher>() != null) return;
        GameObject watcherObject = new GameObject("Novel Scene Watcher");
        UnityEngine.Object.DontDestroyOnLoad(watcherObject);
        watcherObject.AddComponent<NovelSceneWatcher>();
    }
}

public class NovelSceneWatcher : MonoBehaviour
{
    private void OnEnable()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    private void OnDisable()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    private void Start()
    {
        Setup(SceneManager.GetActiveScene());
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        Setup(scene);
    }

    private void Setup(Scene scene)
    {
        if (string.Equals(scene.name, "menu", System.StringComparison.OrdinalIgnoreCase))
        {
            if (HasInScene<MenuSaveUI>(scene)) return;
            GameObject menuObject = new GameObject("Menu Save UI");
            menuObject.AddComponent<MenuSaveUI>();
            return;
        }

        if (HasInScene<NovelRuntime>(scene)) return;
        GameObject runtimeObject = new GameObject("Novel Runtime");
        runtimeObject.AddComponent<NovelRuntime>();
    }

    private static bool HasInScene<T>(Scene scene) where T : Component
    {
        GameObject[] roots = scene.GetRootGameObjects();
        for (int i = 0; i < roots.Length; i++)
        {
            if (roots[i] == null) continue;
            if (roots[i].GetComponentInChildren<T>(true) != null) return true;
        }
        return false;
    }
}

public class NovelRuntime : MonoBehaviour
{
    public static NovelRuntime Instance;

    public DialogueRunner Runner;
    public DayManager Days;
    public DialogueUI UI;
    public PauseMenuUI Pause;
    public BacklogUI Backlog;
    public NovelView View;

    private void Awake()
    {
        Instance = this;

        EnsureEventSystem();

        GameObject viewObject = new GameObject("Novel View");
        viewObject.transform.SetParent(transform, false);
        View = viewObject.AddComponent<NovelView>();
        View.Init();

        Runner = gameObject.AddComponent<DialogueRunner>();
        Days = gameObject.AddComponent<DayManager>();

        GameObject uiObject = new GameObject("Novel UI");
        uiObject.transform.SetParent(transform, false);
        UI = uiObject.AddComponent<DialogueUI>();
        UI.Init(Runner);

        Pause = gameObject.AddComponent<PauseMenuUI>();
        Backlog = gameObject.AddComponent<BacklogUI>();

        Runner.Init(this, UI, View, Days);
        Days.Init(this, Runner);
        Pause.Init(this);
        Backlog.Init(this);
    }

    private void Start()
    {
        GameSession.EnsureInitialized();

        SaveData pending = NovelLaunch.PendingSave;
        NovelLaunch.PendingSave = null;
        NovelLaunch.NewGameRequested = false;

        if (pending != null)
        {
            ApplySave(pending);
            return;
        }

        StartNewGame();
    }

    private void Update()
    {
        GameSession.TickPlayTime();
    }

    private void OnDestroy()
    {
        if (Instance == this) Instance = null;
    }

    public void StartNewGame()
    {
        NovelLaunch.PendingSave = null;
        if (Pause != null) Pause.Close();
        if (Backlog != null) Backlog.Close();
        GameSession.Reset();
        if (UI != null) UI.SetPanelVisible(true);
        if (Days != null) Days.StartDay(1);
    }

    public SaveData BuildSave(int slot)
    {
        SaveData data = GameSession.CreateSave(slot);
        if (Runner != null)
        {
            if (!string.IsNullOrEmpty(Runner.DialogueId)) data.dialogueId = Runner.DialogueId;
            if (!string.IsNullOrEmpty(Runner.NodeId)) data.nodeId = Runner.NodeId;
        }
        return data;
    }

    public bool SaveGame(int slot)
    {
        if (Runner == null || !Runner.IsActive) return false;
        return SaveSystem.Save(slot, BuildSave(slot));
    }

    public void SaveAuto()
    {
        if (Runner == null || !Runner.IsActive) return;
        SaveSystem.SaveAuto(BuildSave(SaveSystem.AutoSlot));
    }

    public void LoadGame(int slot)
    {
        SaveData data;
        if (!SaveSystem.TryLoad(slot, out data)) return;
        ApplySave(data);
    }

    public bool ApplySave(SaveData data)
    {
        if (data == null) return false;

        GameSession.Restore(data);

        string activeScene = SceneManager.GetActiveScene().name;
        string targetScene = string.IsNullOrEmpty(data.sceneName) ? activeScene : data.sceneName;

        if (!Application.CanStreamedLevelBeLoaded(targetScene))
        {
            targetScene = "cats";
            if (!Application.CanStreamedLevelBeLoaded(targetScene)) targetScene = activeScene;
        }

        if (!string.Equals(activeScene, targetScene, System.StringComparison.OrdinalIgnoreCase))
        {
            NovelLaunch.PendingSave = data;
            SceneManager.LoadScene(targetScene);
            return true;
        }

        if (Pause != null) Pause.Close();
        if (Backlog != null) Backlog.Close();
        if (UI != null) UI.SetPanelVisible(true);

        if (Days != null) Days.ResumeFromSave(data);

        bool started = false;
        if (Runner != null && !string.IsNullOrEmpty(data.dialogueId))
            started = Runner.Resume(data.dialogueId, data.nodeId);

        if (!started && Days != null)
        {
            Days.StartDay(data.day);
            started = Runner != null && Runner.IsActive;
        }

        if (!started && UI != null) UI.SetPanelVisible(false);
        return started;
    }

    public void ReturnToMenu(bool autosave)
    {
        if (autosave) SaveAuto();
        SceneManager.LoadScene("menu");
    }

    private static void EnsureEventSystem()
    {
        EventSystem existing = UnityEngine.Object.FindObjectOfType<EventSystem>();
        if (existing != null)
        {
            if (existing.GetComponentInChildren<BaseInputModule>(true) == null)
                existing.gameObject.AddComponent<StandaloneInputModule>();
            return;
        }

        GameObject eventObject = new GameObject("EventSystem");
        eventObject.AddComponent<EventSystem>();
        eventObject.AddComponent<StandaloneInputModule>();
    }
}
