using System;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Novel/Sprite Library", fileName = "SpriteLibrary")]
public class DialogueSpriteLibrary : ScriptableObject
{
    [Serializable]
    public class Entry
    {
        public string key;
        public Sprite sprite;
    }

    public List<Entry> entries = new List<Entry>();

    [NonSerialized] private Dictionary<string, Sprite> map;

    public Sprite Get(string key)
    {
        if (string.IsNullOrEmpty(key)) return null;
        EnsureMap();
        Sprite sprite;
        return map.TryGetValue(Normalize(key), out sprite) ? sprite : null;
    }

    private void EnsureMap()
    {
        if (map != null) return;
        map = new Dictionary<string, Sprite>(StringComparer.OrdinalIgnoreCase);
        for (int i = 0; i < entries.Count; i++)
        {
            Entry entry = entries[i];
            if (entry == null || string.IsNullOrEmpty(entry.key) || entry.sprite == null) continue;
            map[Normalize(entry.key)] = entry.sprite;
        }
    }

    private void OnEnable()
    {
        map = null;
    }

    private void OnValidate()
    {
        map = null;
    }

    private static string Normalize(string key)
    {
        return key.Replace('\\', '/').Trim();
    }
}
