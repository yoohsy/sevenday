using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class GameSession
{
    public static readonly GameVariables Variables = new GameVariables();
    public static int Day = 1;
    public static string CurrentDialogueId;
    public static string CurrentNodeId;
    public static float PlayTimeSeconds;
    public static readonly List<string> History = new List<string>();

    private static float lastTickTime;

    public static void EnsureInitialized()
    {
        if (Variables.Count == 0)
            Reset();
    }

    public static void Reset()
    {
        Variables.Clear();
        Variables.SetInt("day", 1);
        Variables.SetInt("trust", 0);
        Variables.SetBool("hugs_unlocked", false);
        Day = 1;
        CurrentDialogueId = null;
        CurrentNodeId = null;
        PlayTimeSeconds = 0f;
        History.Clear();
        lastTickTime = Time.unscaledTime;
    }

    public static void TickPlayTime()
    {
        float now = Time.unscaledTime;
        if (lastTickTime <= 0f)
        {
            lastTickTime = now;
            return;
        }
        if (now > lastTickTime)
            PlayTimeSeconds += now - lastTickTime;
        lastTickTime = now;
    }

    public static void SetDay(int day)
    {
        Day = Mathf.Max(1, day);
        Variables.SetInt("day", Day);
    }

    public static void AddHistory(string speaker, string text)
    {
        if (string.IsNullOrEmpty(text)) return;
        string entry = string.IsNullOrEmpty(speaker) ? text : speaker + ": " + text;
        if (History.Count > 0 && History[History.Count - 1] == entry) return;
        History.Add(entry);
        while (History.Count > 300)
            History.RemoveAt(0);
    }

    public static SaveData CreateSave(int slot)
    {
        TickPlayTime();
        SaveData data = new SaveData();
        data.slot = slot;
        data.sceneName = SceneManager.GetActiveScene().name;
        data.day = Day;
        data.dialogueId = CurrentDialogueId;
        data.nodeId = CurrentNodeId;
        data.playTimeSeconds = PlayTimeSeconds;
        data.chapter = "День " + Day;
        data.variables = Variables.ToEntries();
        data.history = new List<string>(History);
        return data;
    }

    public static void Restore(SaveData data)
    {
        if (data == null) return;

        Variables.Clear();
        Variables.FromEntries(data.variables);
        SetDay(data.day);
        if (!Variables.Has("trust"))
            Variables.SetInt("trust", 0);
        if (!Variables.Has("hugs_unlocked"))
            Variables.SetBool("hugs_unlocked", false);
        CurrentDialogueId = data.dialogueId;
        CurrentNodeId = data.nodeId;
        PlayTimeSeconds = Mathf.Max(0f, data.playTimeSeconds);
        History.Clear();
        if (data.history != null)
        {
            for (int i = 0; i < data.history.Count; i++)
            {
                if (string.IsNullOrEmpty(data.history[i])) continue;
                History.Add(data.history[i]);
            }
        }
        lastTickTime = Time.unscaledTime;
    }
}
