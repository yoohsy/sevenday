using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using UnityEngine;

public enum NovelValueKind
{
    Number,
    Bool,
    String
}

public struct NovelValue
{
    public NovelValueKind kind;
    public double number;
    public bool boolean;
    public string text;

    public static NovelValue FromNumber(double value)
    {
        NovelValue result = new NovelValue();
        result.kind = NovelValueKind.Number;
        result.number = value;
        return result;
    }

    public static NovelValue FromBool(bool value)
    {
        NovelValue result = new NovelValue();
        result.kind = NovelValueKind.Bool;
        result.boolean = value;
        return result;
    }

    public static NovelValue FromString(string value)
    {
        NovelValue result = new NovelValue();
        result.kind = NovelValueKind.String;
        result.text = value ?? string.Empty;
        return result;
    }

    public bool AsBool()
    {
        switch (kind)
        {
            case NovelValueKind.Number:
                return Math.Abs(number) > 0.00001d;
            case NovelValueKind.Bool:
                return boolean;
            default:
                if (string.IsNullOrEmpty(text)) return false;
                if (string.Equals(text, "false", StringComparison.OrdinalIgnoreCase)) return false;
                if (string.Equals(text, "0", StringComparison.OrdinalIgnoreCase)) return false;
                return true;
        }
    }

    public double AsNumber()
    {
        switch (kind)
        {
            case NovelValueKind.Number:
                return number;
            case NovelValueKind.Bool:
                return boolean ? 1d : 0d;
            default:
                double parsed;
                if (double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out parsed))
                    return parsed;
                return 0d;
        }
    }

    public string AsText()
    {
        switch (kind)
        {
            case NovelValueKind.Number:
                return number.ToString("0.###", CultureInfo.InvariantCulture);
            case NovelValueKind.Bool:
                return boolean ? "true" : "false";
            default:
                return text ?? string.Empty;
        }
    }

    public bool IsNumeric()
    {
        if (kind == NovelValueKind.Number || kind == NovelValueKind.Bool) return true;
        double parsed;
        return double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out parsed);
    }
}

public static class NovelExpression
{
    public static bool TryEvaluate(string expression, GameVariables variables, out NovelValue value, out string error)
    {
        value = NovelValue.FromBool(false);
        error = null;

        if (string.IsNullOrEmpty(expression) || expression.Trim().Length == 0)
        {
            error = "Пустое выражение";
            return false;
        }

        try
        {
            Parser parser = new Parser(expression, variables);
            value = parser.ParseExpression();
            parser.ExpectEnd();
            return true;
        }
        catch (Exception exception)
        {
            error = exception.Message;
            return false;
        }
    }

    private class Parser
    {
        private readonly string source;
        private readonly GameVariables variables;
        private int position;

        public Parser(string source, GameVariables variables)
        {
            this.source = source ?? string.Empty;
            this.variables = variables;
            position = 0;
        }

        public NovelValue ParseExpression()
        {
            return ParseOr();
        }

        public void ExpectEnd()
        {
            SkipWhitespace();
            if (position < source.Length)
                throw new Exception("Лишний символ: '" + source[position] + "'");
        }

        private NovelValue ParseOr()
        {
            NovelValue left = ParseAnd();
            while (Match("||"))
            {
                NovelValue right = ParseAnd();
                left = NovelValue.FromBool(left.AsBool() || right.AsBool());
            }
            return left;
        }

        private NovelValue ParseAnd()
        {
            NovelValue left = ParseEquality();
            while (Match("&&"))
            {
                NovelValue right = ParseEquality();
                left = NovelValue.FromBool(left.AsBool() && right.AsBool());
            }
            return left;
        }

        private NovelValue ParseEquality()
        {
            NovelValue left = ParseComparison();
            while (true)
            {
                if (Match("=="))
                {
                    NovelValue right = ParseComparison();
                    left = NovelValue.FromBool(AreEqual(left, right));
                }
                else if (Match("!="))
                {
                    NovelValue right = ParseComparison();
                    left = NovelValue.FromBool(!AreEqual(left, right));
                }
                else
                {
                    return left;
                }
            }
        }

        private NovelValue ParseComparison()
        {
            NovelValue left = ParseAdd();
            while (true)
            {
                if (Match(">="))
                {
                    NovelValue right = ParseAdd();
                    left = NovelValue.FromBool(Compare(left, right) >= 0);
                }
                else if (Match("<="))
                {
                    NovelValue right = ParseAdd();
                    left = NovelValue.FromBool(Compare(left, right) <= 0);
                }
                else if (Match(">"))
                {
                    NovelValue right = ParseAdd();
                    left = NovelValue.FromBool(Compare(left, right) > 0);
                }
                else if (Match("<"))
                {
                    NovelValue right = ParseAdd();
                    left = NovelValue.FromBool(Compare(left, right) < 0);
                }
                else
                {
                    return left;
                }
            }
        }

        private NovelValue ParseAdd()
        {
            NovelValue left = ParseMul();
            while (true)
            {
                if (Match("+"))
                {
                    NovelValue right = ParseMul();
                    if (left.kind == NovelValueKind.String || right.kind == NovelValueKind.String)
                        left = NovelValue.FromString(left.AsText() + right.AsText());
                    else
                        left = NovelValue.FromNumber(left.AsNumber() + right.AsNumber());
                }
                else if (Match("-"))
                {
                    NovelValue right = ParseMul();
                    left = NovelValue.FromNumber(left.AsNumber() - right.AsNumber());
                }
                else
                {
                    return left;
                }
            }
        }

        private NovelValue ParseMul()
        {
            NovelValue left = ParseUnary();
            while (true)
            {
                if (Match("*"))
                {
                    NovelValue right = ParseUnary();
                    left = NovelValue.FromNumber(left.AsNumber() * right.AsNumber());
                }
                else if (Match("/"))
                {
                    NovelValue right = ParseUnary();
                    double divisor = right.AsNumber();
                    if (Math.Abs(divisor) < 0.0000001d) throw new Exception("Деление на ноль");
                    left = NovelValue.FromNumber(left.AsNumber() / divisor);
                }
                else if (Match("%"))
                {
                    NovelValue right = ParseUnary();
                    double divisor = right.AsNumber();
                    if (Math.Abs(divisor) < 0.0000001d) throw new Exception("Деление на ноль");
                    left = NovelValue.FromNumber(left.AsNumber() % divisor);
                }
                else
                {
                    return left;
                }
            }
        }

        private NovelValue ParseUnary()
        {
            if (Match("!"))
                return NovelValue.FromBool(!ParseUnary().AsBool());
            if (Match("-"))
                return NovelValue.FromNumber(-ParseUnary().AsNumber());
            if (Match("+"))
                return ParseUnary();
            return ParsePrimary();
        }

        private NovelValue ParsePrimary()
        {
            SkipWhitespace();
            if (position >= source.Length)
                throw new Exception("Неожиданный конец выражения");

            char current = source[position];

            if (current == '(')
            {
                position++;
                NovelValue value = ParseOr();
                if (!Match(")")) throw new Exception("Не закрыта скобка");
                return value;
            }

            if (current == '"' || current == '\'')
                return ParseString(current);

            if (char.IsDigit(current) || (current == '.' && position + 1 < source.Length && char.IsDigit(source[position + 1])))
                return ParseNumber();

            if (char.IsLetter(current) || current == '_')
                return ParseIdentifier();

            throw new Exception("Неожиданный символ: '" + current + "'");
        }

        private NovelValue ParseString(char quote)
        {
            position++;
            StringBuilder builder = new StringBuilder();
            while (position < source.Length)
            {
                char current = source[position++];
                if (current == quote)
                    return NovelValue.FromString(builder.ToString());
                if (current == '\\' && position < source.Length)
                {
                    char escaped = source[position++];
                    switch (escaped)
                    {
                        case 'n': builder.Append('\n'); break;
                        case 'r': builder.Append('\r'); break;
                        case 't': builder.Append('\t'); break;
                        case '\\': builder.Append('\\'); break;
                        case '"': builder.Append('"'); break;
                        case '\'': builder.Append('\''); break;
                        default: builder.Append(escaped); break;
                    }
                }
                else
                {
                    builder.Append(current);
                }
            }
            throw new Exception("Не закрыта строка");
        }

        private NovelValue ParseNumber()
        {
            int start = position;
            bool hasDot = false;
            while (position < source.Length)
            {
                char current = source[position];
                if (char.IsDigit(current))
                {
                    position++;
                    continue;
                }
                if (current == '.' && !hasDot)
                {
                    hasDot = true;
                    position++;
                    continue;
                }
                break;
            }
            string numberText = source.Substring(start, position - start);
            double parsed;
            if (!double.TryParse(numberText, NumberStyles.Float, CultureInfo.InvariantCulture, out parsed))
                throw new Exception("Некорректное число: " + numberText);
            return NovelValue.FromNumber(parsed);
        }

        private NovelValue ParseIdentifier()
        {
            int start = position;
            while (position < source.Length)
            {
                char current = source[position];
                if (char.IsLetterOrDigit(current) || current == '_' || current == '.')
                    position++;
                else
                    break;
            }
            string name = source.Substring(start, position - start);

            if (string.Equals(name, "true", StringComparison.OrdinalIgnoreCase))
                return NovelValue.FromBool(true);
            if (string.Equals(name, "false", StringComparison.OrdinalIgnoreCase))
                return NovelValue.FromBool(false);

            GameVariable variable;
            if (variables != null && variables.TryGet(name, out variable))
            {
                switch (variable.type)
                {
                    case GameVariableType.Int:
                    case GameVariableType.Float:
                        return NovelValue.FromNumber(variable.AsNumber());
                    case GameVariableType.Bool:
                        return NovelValue.FromBool(variable.boolValue);
                    default:
                        return NovelValue.FromString(variable.stringValue);
                }
            }

            throw new Exception("Неизвестная переменная: " + name);
        }

        private bool Match(string token)
        {
            SkipWhitespace();
            if (position + token.Length > source.Length) return false;
            if (string.CompareOrdinal(source, position, token, 0, token.Length) != 0) return false;
            position += token.Length;
            return true;
        }

        private void SkipWhitespace()
        {
            while (position < source.Length && char.IsWhiteSpace(source[position]))
                position++;
        }

        private static bool AreEqual(NovelValue left, NovelValue right)
        {
            if (left.kind == NovelValueKind.String || right.kind == NovelValueKind.String)
                return string.Equals(left.AsText(), right.AsText(), StringComparison.Ordinal);
            if (left.kind == NovelValueKind.Bool && right.kind == NovelValueKind.Bool)
                return left.boolean == right.boolean;
            return Math.Abs(left.AsNumber() - right.AsNumber()) < 0.0000001d;
        }

        private static int Compare(NovelValue left, NovelValue right)
        {
            if (left.kind == NovelValueKind.String || right.kind == NovelValueKind.String)
                return string.CompareOrdinal(left.AsText(), right.AsText());
            return left.AsNumber().CompareTo(right.AsNumber());
        }
    }
}

public static class NovelConditions
{
    public static bool Evaluate(string expression, GameVariables variables)
    {
        if (string.IsNullOrEmpty(expression) || expression.Trim().Length == 0)
            return true;

        NovelValue value;
        string error;
        if (!NovelExpression.TryEvaluate(expression, variables, out value, out error))
        {
            Debug.LogWarning("[Novel] Ошибка условия '" + expression + "': " + error);
            return false;
        }
        return value.AsBool();
    }
}

public static class NovelEffects
{
    public static void Apply(List<string> effects, GameVariables variables)
    {
        if (effects == null || variables == null) return;
        for (int i = 0; i < effects.Count; i++)
            ApplyOne(effects[i], variables);
    }

    private static void ApplyOne(string statement, GameVariables variables)
    {
        if (string.IsNullOrEmpty(statement) || statement.Trim().Length == 0) return;

        string raw = statement.Trim();
        int operatorIndex = FindOperator(raw, out string op);
        if (operatorIndex < 0)
        {
            Debug.LogWarning("[Novel] Эффект без оператора: " + statement);
            return;
        }

        string key = raw.Substring(0, operatorIndex).Trim();
        string right = raw.Substring(operatorIndex + op.Length).Trim();

        if (!IsIdentifier(key))
        {
            Debug.LogWarning("[Novel] Некорректное имя переменной: " + key);
            return;
        }

        if (op == "=")
        {
            NovelValue value;
            string error;
            if (!NovelExpression.TryEvaluate(right, variables, out value, out error))
            {
                Debug.LogWarning("[Novel] Ошибка эффекта '" + statement + "': " + error);
                return;
            }

            if (value.kind == NovelValueKind.Bool)
                variables.SetBool(key, value.AsBool());
            else if (value.kind == NovelValueKind.String)
                variables.SetString(key, value.AsText());
            else
                variables.SetNumber(key, value.AsNumber());
            return;
        }

        double delta;
        NovelValue deltaValue;
        string deltaError;
        if (!NovelExpression.TryEvaluate(right, variables, out deltaValue, out deltaError))
        {
            Debug.LogWarning("[Novel] Ошибка эффекта '" + statement + "': " + deltaError);
            return;
        }
        delta = deltaValue.AsNumber();

        if (op == "+=")
        {
            GameVariable current;
            if (variables.TryGet(key, out current) && current.type == GameVariableType.String)
            {
                variables.SetString(key, current.AsText() + deltaValue.AsText());
                return;
            }
            variables.AddNumber(key, delta);
            return;
        }

        if (op == "-=")
        {
            GameVariable current;
            if (variables.TryGet(key, out current) && !current.IsNumber())
            {
                Debug.LogWarning("[Novel] Нельзя вычесть из нечисловой переменной: " + key);
                return;
            }
            variables.AddNumber(key, -delta);
        }
    }

    private static int FindOperator(string text, out string op)
    {
        op = null;
        char quote = '\0';
        for (int i = 0; i < text.Length; i++)
        {
            char current = text[i];
            if (quote != '\0')
            {
                if (current == '\\')
                {
                    i++;
                    continue;
                }
                if (current == quote) quote = '\0';
                continue;
            }
            if (current == '"' || current == '\'')
            {
                quote = current;
                continue;
            }

            if (current == '+' && i + 1 < text.Length && text[i + 1] == '=')
            {
                op = "+=";
                return i;
            }
            if (current == '-' && i + 1 < text.Length && text[i + 1] == '=')
            {
                op = "-=";
                return i;
            }
            if (current == '=')
            {
                char previous = i > 0 ? text[i - 1] : '\0';
                char next = i + 1 < text.Length ? text[i + 1] : '\0';
                if (next == '=') { i++; continue; }
                if (previous == '=' || previous == '!' || previous == '<' || previous == '>') continue;
                op = "=";
                return i;
            }
        }
        return -1;
    }

    private static bool IsIdentifier(string text)
    {
        if (string.IsNullOrEmpty(text)) return false;
        if (!char.IsLetter(text[0]) && text[0] != '_') return false;
        for (int i = 1; i < text.Length; i++)
        {
            char current = text[i];
            if (!char.IsLetterOrDigit(current) && current != '_' && current != '.') return false;
        }
        return true;
    }
}

public static class NovelText
{
    public static string Format(string text, GameVariables variables)
    {
        if (string.IsNullOrEmpty(text) || variables == null) return text ?? string.Empty;
        if (text.IndexOf('{') < 0) return text;

        StringBuilder builder = new StringBuilder(text.Length + 16);
        int index = 0;
        while (index < text.Length)
        {
            char current = text[index];
            if (current != '{')
            {
                builder.Append(current);
                index++;
                continue;
            }

            int close = text.IndexOf('}', index + 1);
            if (close < 0)
            {
                builder.Append(text.Substring(index));
                break;
            }

            string key = text.Substring(index + 1, close - index - 1).Trim();
            GameVariable variable;
            if (variables.TryGet(key, out variable))
                builder.Append(variable.AsText());
            else
                builder.Append(text.Substring(index, close - index + 1));

            index = close + 1;
        }
        return builder.ToString();
    }
}
