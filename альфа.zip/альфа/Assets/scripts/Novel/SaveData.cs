using System;
using System.Collections.Generic;

[Serializable]
public class SaveData
{
    public int version = 1;
    public int slot;
    public string savedAtUtc;
    public float playTimeSeconds;
    public string sceneName;
    public int day;
    public string chapter;
    public string dialogueId;
    public string nodeId;
    public List<VariableEntry> variables = new List<VariableEntry>();
    public List<string> history = new List<string>();
}
