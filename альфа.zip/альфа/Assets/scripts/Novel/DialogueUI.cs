using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class DialogueUI : MonoBehaviour
{
    private DialogueRunner runner;
    private Canvas canvas;
    private GameObject dialogPanel;
    private TMP_Text nameText;
    private TMP_Text dialogueText;
    private GameObject choicePanel;
    private RectTransform choiceRect;
    private readonly List<GameObject> choiceButtons = new List<GameObject>();
    private TMP_Text statusText;
    private Image fadeImage;
    private GameObject toastRoot;
    private CanvasGroup toastGroup;
    private TMP_Text toastText;

    private TMP_FontAsset font;
    private Coroutine typeRoutine;
    private Coroutine fadeRoutine;
    private Coroutine toastRoutine;
    private bool isTyping;
    private int totalCharacters;
    private int visibleCharacters;
    private float charsPerSecond = 45f;
    private string fullText = string.Empty;
    private int lineVersion;

    public bool IsTyping { get { return isTyping; } }
    public bool ChoicesVisible { get; private set; }
    public int CharacterCount { get { return totalCharacters; } }
    public TMP_FontAsset Font { get { return font; } }

    public void Init(DialogueRunner runner)
    {
        this.runner = runner;
        EnsureUI();
    }

    private void EnsureUI()
    {
        Transform panel = FindDeep("dialog panel");
        if (panel != null)
        {
            Canvas parentCanvas = panel.GetComponentInParent<Canvas>();
            if (parentCanvas != null) canvas = parentCanvas;
        }

        if (canvas == null)
        {
            Canvas[] canvases = UnityEngine.Object.FindObjectsOfType<Canvas>(true);
            for (int i = 0; i < canvases.Length; i++)
            {
                if (canvases[i] != null && canvases[i].renderMode == RenderMode.ScreenSpaceOverlay)
                {
                    canvas = canvases[i];
                    break;
                }
            }
        }

        if (canvas == null)
            canvas = CreateCanvas();

        if (canvas.GetComponent<GraphicRaycaster>() == null)
            canvas.gameObject.AddComponent<GraphicRaycaster>();

        EnsureEventSystem();

        if (panel != null)
        {
            dialogPanel = panel.gameObject;
            dialogPanel.SetActive(true);
            nameText = FindTextIn(dialogPanel.transform, "name char");
            dialogueText = FindTextIn(dialogPanel.transform, "dialog");
            if (font == null && dialogueText != null) font = dialogueText.font;
            if (font == null && nameText != null) font = nameText.font;
        }
        else
        {
            CreateDialogPanel();
        }

        if (font == null) font = TMP_Settings.defaultFontAsset;
        if (font == null) font = Resources.Load<TMP_FontAsset>("Fonts & Materials/LiberationSans SDF");
        if (font == null) Debug.LogError("[Novel] Не найден TMP-шрифт. Импортируйте TMP Essentials.");

        EnsureTexts();

        dialogPanel.transform.SetAsLastSibling();
        CreateChoicePanel();
        CreateStatus();
        CreateFade();
        CreateToast();

        SetStatus(string.Empty);
    }

    private Canvas CreateCanvas()
    {
        GameObject canvasObject = new GameObject("Novel Canvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        Canvas created = canvasObject.GetComponent<Canvas>();
        created.renderMode = RenderMode.ScreenSpaceOverlay;
        CanvasScaler scaler = canvasObject.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1280f, 720f);
        scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        scaler.matchWidthOrHeight = 0.5f;
        return created;
    }

    private void CreateDialogPanel()
    {
        GameObject panelObject = new GameObject("dialog panel", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        panelObject.transform.SetParent(canvas.transform, false);
        RectTransform rect = panelObject.GetComponent<RectTransform>();
        rect.anchorMin = new Vector2(0.06f, 0.03f);
        rect.anchorMax = new Vector2(0.94f, 0.31f);
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;

        Image image = panelObject.GetComponent<Image>();
        image.color = new Color(0.03f, 0.04f, 0.06f, 0.78f);
        image.raycastTarget = false;

        dialogPanel = panelObject;
        nameText = CreateText("name char", dialogPanel.transform, string.Empty, 30f, new Color(1f, 0.88f, 0.68f, 1f));
        RectTransform nameRect = nameText.rectTransform;
        nameRect.anchorMin = new Vector2(0.03f, 0.66f);
        nameRect.anchorMax = new Vector2(0.97f, 0.98f);
        nameRect.offsetMin = Vector2.zero;
        nameRect.offsetMax = Vector2.zero;
        nameText.fontStyle = FontStyles.Bold;
        nameText.alignment = TextAlignmentOptions.Left;
        nameText.enableWordWrapping = false;

        dialogueText = CreateText("dialog", dialogPanel.transform, string.Empty, 28f, Color.white);
        RectTransform dialogRect = dialogueText.rectTransform;
        dialogRect.anchorMin = new Vector2(0.03f, 0.05f);
        dialogRect.anchorMax = new Vector2(0.97f, 0.64f);
        dialogRect.offsetMin = Vector2.zero;
        dialogRect.offsetMax = Vector2.zero;
        dialogueText.alignment = TextAlignmentOptions.TopLeft;
        dialogueText.lineSpacing = 6f;
    }

    private void EnsureTexts()
    {
        if (dialogPanel == null) return;

        if (nameText == null)
        {
            nameText = CreateText("name char", dialogPanel.transform, string.Empty, 30f, new Color(1f, 0.88f, 0.68f, 1f));
            RectTransform nameRect = nameText.rectTransform;
            nameRect.anchorMin = new Vector2(0.03f, 0.66f);
            nameRect.anchorMax = new Vector2(0.97f, 0.98f);
            nameRect.offsetMin = Vector2.zero;
            nameRect.offsetMax = Vector2.zero;
            nameText.fontStyle = FontStyles.Bold;
            nameText.alignment = TextAlignmentOptions.Left;
            nameText.enableWordWrapping = false;
        }

        if (dialogueText == null)
        {
            dialogueText = CreateText("dialog", dialogPanel.transform, string.Empty, 28f, Color.white);
            RectTransform dialogRect = dialogueText.rectTransform;
            dialogRect.anchorMin = new Vector2(0.03f, 0.05f);
            dialogRect.anchorMax = new Vector2(0.97f, 0.64f);
            dialogRect.offsetMin = Vector2.zero;
            dialogRect.offsetMax = Vector2.zero;
            dialogueText.alignment = TextAlignmentOptions.TopLeft;
            dialogueText.lineSpacing = 6f;
        }

        if (font != null)
        {
            if (nameText != null) nameText.font = font;
            if (dialogueText != null) dialogueText.font = font;
        }

        if (nameText != null) nameText.raycastTarget = false;
        if (dialogueText != null) dialogueText.raycastTarget = false;
    }

    private void CreateChoicePanel()
    {
        GameObject choiceObject = new GameObject("Novel Choices", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(VerticalLayoutGroup), typeof(ContentSizeFitter));
        choiceObject.transform.SetParent(canvas.transform, false);
        choiceRect = choiceObject.GetComponent<RectTransform>();
        choiceRect.anchorMin = new Vector2(0.5f, 0f);
        choiceRect.anchorMax = new Vector2(0.5f, 0f);
        choiceRect.pivot = new Vector2(0.5f, 0f);
        choiceRect.anchoredPosition = new Vector2(0f, 235f);
        choiceRect.sizeDelta = new Vector2(860f, 10f);

        Image image = choiceObject.GetComponent<Image>();
        image.color = new Color(0.03f, 0.04f, 0.06f, 0.9f);
        image.raycastTarget = true;

        VerticalLayoutGroup layout = choiceObject.GetComponent<VerticalLayoutGroup>();
        layout.padding = new RectOffset(12, 12, 12, 12);
        layout.spacing = 6f;
        layout.childAlignment = TextAnchor.MiddleCenter;
        layout.childControlWidth = true;
        layout.childControlHeight = true;
        layout.childForceExpandWidth = true;
        layout.childForceExpandHeight = false;

        ContentSizeFitter fitter = choiceObject.GetComponent<ContentSizeFitter>();
        fitter.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
        fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

        choicePanel = choiceObject;
        choicePanel.SetActive(false);
    }

    private void CreateStatus()
    {
        statusText = CreateText("Novel Status", canvas.transform, string.Empty, 20f, new Color(1f, 0.85f, 0.35f, 1f));
        RectTransform rect = statusText.rectTransform;
        rect.anchorMin = new Vector2(0.01f, 0.93f);
        rect.anchorMax = new Vector2(0.35f, 0.99f);
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
        statusText.alignment = TextAlignmentOptions.TopLeft;
        statusText.raycastTarget = false;
    }

    private void CreateFade()
    {
        GameObject fadeObject = new GameObject("Novel Fade", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        fadeObject.transform.SetParent(canvas.transform, false);
        RectTransform rect = fadeObject.GetComponent<RectTransform>();
        rect.anchorMin = Vector2.zero;
        rect.anchorMax = Vector2.one;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
        fadeImage = fadeObject.GetComponent<Image>();
        fadeImage.color = new Color(0f, 0f, 0f, 0f);
        fadeImage.raycastTarget = false;
    }

    private void CreateToast()
    {
        toastRoot = new GameObject("Novel Toast", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(CanvasGroup));
        toastRoot.transform.SetParent(canvas.transform, false);
        RectTransform rect = toastRoot.GetComponent<RectTransform>();
        rect.anchorMin = new Vector2(0.28f, 0.82f);
        rect.anchorMax = new Vector2(0.72f, 0.9f);
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
        Image background = toastRoot.GetComponent<Image>();
        background.color = new Color(0f, 0f, 0f, 0.7f);
        background.raycastTarget = false;
        toastGroup = toastRoot.GetComponent<CanvasGroup>();
        toastGroup.alpha = 0f;
        toastGroup.blocksRaycasts = false;

        toastText = CreateText("toast", toastRoot.transform, string.Empty, 22f, Color.white);
        RectTransform textRect = toastText.rectTransform;
        textRect.anchorMin = Vector2.zero;
        textRect.anchorMax = Vector2.one;
        textRect.offsetMin = new Vector2(12f, 4f);
        textRect.offsetMax = new Vector2(-12f, -4f);
        toastText.alignment = TextAlignmentOptions.Center;
        toastText.raycastTarget = false;
    }

    public void ShowLine(string speaker, string text)
    {
        if (dialogPanel != null) dialogPanel.SetActive(true);

        if (nameText != null)
        {
            bool hasSpeaker = !string.IsNullOrEmpty(speaker);
            nameText.gameObject.SetActive(hasSpeaker);
            if (hasSpeaker) nameText.text = speaker;
        }

        fullText = text ?? string.Empty;
        lineVersion++;
        int version = lineVersion;
        if (dialogueText == null) return;

        if (typeRoutine != null)
        {
            StopCoroutine(typeRoutine);
            typeRoutine = null;
        }

        dialogueText.text = fullText;
        dialogueText.maxVisibleCharacters = 0;
        dialogueText.ForceMeshUpdate();
        totalCharacters = dialogueText.textInfo.characterCount;
        visibleCharacters = 0;

        if (totalCharacters <= 0)
        {
            isTyping = false;
            dialogueText.maxVisibleCharacters = 0;
            StartCoroutine(NotifyNextFrame(version));
            return;
        }

        isTyping = true;
        typeRoutine = StartCoroutine(TypeRoutine(version));
    }

    private IEnumerator TypeRoutine(int version)
    {
        float accumulator = 0f;
        while (visibleCharacters < totalCharacters)
        {
            if (version != lineVersion) yield break;
            accumulator += Time.unscaledDeltaTime * Mathf.Max(1f, charsPerSecond);
            int step = Mathf.FloorToInt(accumulator);
            if (step > 0)
            {
                accumulator -= step;
                visibleCharacters += step;
                if (visibleCharacters > totalCharacters) visibleCharacters = totalCharacters;
                if (dialogueText != null) dialogueText.maxVisibleCharacters = visibleCharacters;
            }
            yield return null;
        }

        typeRoutine = null;
        isTyping = false;
        if (version != lineVersion) yield break;
        if (dialogueText != null) dialogueText.maxVisibleCharacters = totalCharacters;
        if (runner != null) runner.OnTypingComplete();
    }

    private IEnumerator NotifyNextFrame(int version)
    {
        yield return null;
        if (version != lineVersion) yield break;
        if (runner != null) runner.OnTypingComplete();
    }

    public void CompleteTyping()
    {
        if (!isTyping) return;
        if (typeRoutine != null)
        {
            StopCoroutine(typeRoutine);
            typeRoutine = null;
        }
        isTyping = false;
        if (dialogueText != null) dialogueText.maxVisibleCharacters = Mathf.Max(0, totalCharacters);
        if (runner != null) runner.OnTypingComplete();
    }

    public void ShowChoices(List<DialogueChoice> choices, Action<DialogueChoice> onChoice)
    {
        HideChoices();
        if (choices == null || choices.Count == 0 || choicePanel == null) return;

        choicePanel.SetActive(true);
        for (int i = 0; i < choices.Count; i++)
        {
            DialogueChoice choice = choices[i];
            if (choice == null) continue;
            CreateChoiceButton(choice, i, onChoice);
        }

        Canvas.ForceUpdateCanvases();
        if (choiceRect != null) LayoutRebuilder.ForceRebuildLayoutImmediate(choiceRect);
        ChoicesVisible = true;
    }

    private void CreateChoiceButton(DialogueChoice choice, int index, Action<DialogueChoice> onChoice)
    {
        GameObject buttonObject = new GameObject("choice " + (index + 1), typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(Button), typeof(LayoutElement));
        buttonObject.transform.SetParent(choicePanel.transform, false);

        Image image = buttonObject.GetComponent<Image>();
        image.color = new Color(0.16f, 0.19f, 0.24f, 1f);

        Button button = buttonObject.GetComponent<Button>();
        button.targetGraphic = image;
        button.transition = Selectable.Transition.ColorTint;
        ColorBlock colors = button.colors;
        colors.normalColor = Color.white;
        colors.highlightedColor = new Color(0.66f, 0.82f, 1f, 1f);
        colors.pressedColor = new Color(0.52f, 0.7f, 0.9f, 1f);
        colors.selectedColor = Color.white;
        colors.disabledColor = new Color(0.5f, 0.5f, 0.5f, 0.5f);
        colors.fadeDuration = 0.08f;
        button.colors = colors;
        Navigation navigation = new Navigation();
        navigation.mode = Navigation.Mode.None;
        button.navigation = navigation;

        LayoutElement layout = buttonObject.GetComponent<LayoutElement>();
        layout.minHeight = 48f;
        layout.preferredHeight = 52f;
        layout.flexibleHeight = 0f;

        string labelText = NovelText.Format(choice.text, GameSession.Variables);
        TextMeshProUGUI label = CreateText("label", buttonObject.transform, labelText, 23f, Color.white);
        RectTransform labelRect = label.rectTransform;
        labelRect.anchorMin = Vector2.zero;
        labelRect.anchorMax = Vector2.one;
        labelRect.offsetMin = new Vector2(18f, 6f);
        labelRect.offsetMax = new Vector2(-18f, -6f);
        label.alignment = TextAlignmentOptions.Left;
        label.enableWordWrapping = true;
        label.raycastTarget = false;

        DialogueChoice captured = choice;
        button.onClick.AddListener(delegate
        {
            if (onChoice != null) onChoice(captured);
        });

        choiceButtons.Add(buttonObject);
    }

    public void HideChoices()
    {
        for (int i = 0; i < choiceButtons.Count; i++)
        {
            if (choiceButtons[i] != null) Destroy(choiceButtons[i]);
        }
        choiceButtons.Clear();
        ChoicesVisible = false;
        if (choicePanel != null) choicePanel.SetActive(false);
    }

    public void SetPanelVisible(bool visible)
    {
        if (dialogPanel != null) dialogPanel.SetActive(visible);
        if (!visible) HideChoices();
    }

    public void SetStatus(string text)
    {
        if (statusText != null) statusText.text = text ?? string.Empty;
    }

    public void ShowToast(string text, float seconds = 2f)
    {
        if (toastRoot == null || toastText == null) return;
        toastText.text = text ?? string.Empty;
        if (toastRoutine != null) StopCoroutine(toastRoutine);
        toastRoutine = StartCoroutine(ToastRoutine(seconds));
    }

    private IEnumerator ToastRoutine(float seconds)
    {
        if (toastGroup != null) toastGroup.alpha = 1f;
        float hold = Mathf.Max(0.1f, seconds);
        yield return new WaitForSecondsRealtime(hold);

        float elapsed = 0f;
        while (elapsed < 0.35f)
        {
            elapsed += Time.unscaledDeltaTime;
            if (toastGroup != null) toastGroup.alpha = 1f - Mathf.Clamp01(elapsed / 0.35f);
            yield return null;
        }
        if (toastGroup != null) toastGroup.alpha = 0f;
        toastRoutine = null;
    }

    public IEnumerator FadeTo(float targetAlpha, float duration)
    {
        if (fadeImage == null) yield break;
        if (fadeRoutine != null) StopCoroutine(fadeRoutine);
        fadeRoutine = StartCoroutine(FadeRoutine(targetAlpha, duration));
        yield return fadeRoutine;
        fadeRoutine = null;
    }

    private IEnumerator FadeRoutine(float targetAlpha, float duration)
    {
        float start = fadeImage.color.a;
        float time = Mathf.Max(0.01f, duration);
        float elapsed = 0f;
        while (elapsed < time)
        {
            elapsed += Time.unscaledDeltaTime;
            float t = Mathf.Clamp01(elapsed / time);
            Color color = fadeImage.color;
            color.a = Mathf.Lerp(start, targetAlpha, t);
            fadeImage.color = color;
            yield return null;
        }
        Color finalColor = fadeImage.color;
        finalColor.a = targetAlpha;
        fadeImage.color = finalColor;
    }

    private TextMeshProUGUI CreateText(string name, Transform parent, string text, float size, Color color)
    {
        GameObject textObject = new GameObject(name, typeof(RectTransform));
        textObject.transform.SetParent(parent, false);
        TextMeshProUGUI component = textObject.AddComponent<TextMeshProUGUI>();
        component.text = text;
        component.fontSize = size;
        component.color = color;
        component.enableWordWrapping = true;
        component.raycastTarget = false;
        if (font != null) component.font = font;
        return component;
    }

    private static TMP_Text FindTextIn(Transform root, string name)
    {
        TMP_Text[] texts = root.GetComponentsInChildren<TMP_Text>(true);
        for (int i = 0; i < texts.Length; i++)
        {
            if (texts[i] == null) continue;
            if (string.Equals(texts[i].name.Trim(), name, StringComparison.OrdinalIgnoreCase))
                return texts[i];
        }
        return null;
    }

    private static Transform FindDeep(string name)
    {
        Transform[] transforms = UnityEngine.Object.FindObjectsOfType<Transform>(true);
        for (int i = 0; i < transforms.Length; i++)
        {
            if (transforms[i] == null) continue;
            if (string.Equals(transforms[i].name.Trim(), name, StringComparison.OrdinalIgnoreCase))
                return transforms[i];
        }
        return null;
    }

    private static void EnsureEventSystem()
    {
        EventSystem existing = UnityEngine.Object.FindObjectOfType<EventSystem>();
        if (existing != null)
        {
            if (existing.GetComponentInChildren<BaseInputModule>(true) == null)
                existing.gameObject.AddComponent<StandaloneInputModule>();
            return;
        }

        GameObject eventObject = new GameObject("EventSystem");
        eventObject.AddComponent<EventSystem>();
        eventObject.AddComponent<StandaloneInputModule>();
    }
}
