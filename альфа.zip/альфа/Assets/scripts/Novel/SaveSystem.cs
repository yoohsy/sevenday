using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using UnityEngine;

[Serializable]
public class SeenData
{
    public List<string> nodes = new List<string>();
}

public static class SaveSystem
{
    public const int CurrentVersion = 1;
    public const int AutoSlot = 0;
    public const int SlotCount = 10;

    public static string SaveDirectory
    {
        get { return Path.Combine(Application.persistentDataPath, "Saves"); }
    }

    public static string SlotPath(int slot)
    {
        if (slot == AutoSlot) return Path.Combine(SaveDirectory, "autosave.json");
        return Path.Combine(SaveDirectory, "slot" + slot + ".json");
    }

    public static bool HasSave(int slot)
    {
        string path = SlotPath(slot);
        return File.Exists(path) || File.Exists(path + ".bak");
    }

    public static bool TryLoad(int slot, out SaveData data)
    {
        return TryLoadFile(SlotPath(slot), out data, true);
    }

    public static bool TryLoadFile(string path, out SaveData data, bool allowBackup)
    {
        data = null;
        if (string.IsNullOrEmpty(path) || !File.Exists(path))
        {
            if (allowBackup && !string.IsNullOrEmpty(path) && File.Exists(path + ".bak"))
                return TryLoadFile(path + ".bak", out data, false);
            return false;
        }

        try
        {
            string json = File.ReadAllText(path, Encoding.UTF8);
            SaveData parsed = JsonUtility.FromJson<SaveData>(json);
            if (parsed == null)
            {
                Debug.LogWarning("[Novel] Пустой файл сохранения: " + path);
                if (allowBackup && File.Exists(path + ".bak"))
                    return TryLoadFile(path + ".bak", out data, false);
                return false;
            }
            if (parsed.version > CurrentVersion)
            {
                Debug.LogWarning("[Novel] Версия сохранения новее игры: " + parsed.version);
                return false;
            }
            if (parsed.variables == null) parsed.variables = new List<VariableEntry>();
            if (parsed.history == null) parsed.history = new List<string>();
            data = parsed;
            return true;
        }
        catch (Exception exception)
        {
            Debug.LogWarning("[Novel] Не удалось прочитать сохранение " + path + ": " + exception.Message);
            if (allowBackup && File.Exists(path + ".bak"))
                return TryLoadFile(path + ".bak", out data, false);
            return false;
        }
    }

    public static bool Save(int slot, SaveData data)
    {
        if (data == null) return false;

        try
        {
            Directory.CreateDirectory(SaveDirectory);
            data.version = CurrentVersion;
            data.slot = slot;
            data.savedAtUtc = DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture);
            string json = JsonUtility.ToJson(data, true);
            string path = SlotPath(slot);
            string temp = path + ".tmp";
            File.WriteAllText(temp, json, new UTF8Encoding(false));

            if (File.Exists(path))
            {
                try
                {
                    File.Replace(temp, path, path + ".bak");
                    return true;
                }
                catch
                {
                    try { File.Copy(path, path + ".bak", true); } catch { }
                    try { File.Delete(path); } catch { }
                }
            }

            File.Move(temp, path);
            return true;
        }
        catch (Exception exception)
        {
            Debug.LogError("[Novel] Не удалось сохранить слот " + slot + ": " + exception.Message);
            return false;
        }
    }

    public static bool SaveAuto(SaveData data)
    {
        return Save(AutoSlot, data);
    }

    public static void Delete(int slot)
    {
        try
        {
            string path = SlotPath(slot);
            if (File.Exists(path)) File.Delete(path);
            if (File.Exists(path + ".bak")) File.Delete(path + ".bak");
        }
        catch (Exception exception)
        {
            Debug.LogWarning("[Novel] Не удалось удалить сохранение: " + exception.Message);
        }
    }

    public static SaveData Peek(int slot)
    {
        SaveData data;
        if (TryLoad(slot, out data)) return data;
        return null;
    }

    public static int FindLatestSlot(out SaveData latest)
    {
        latest = null;
        int bestSlot = -1;
        DateTime bestTime = DateTime.MinValue;

        for (int slot = AutoSlot; slot <= SlotCount; slot++)
        {
            SaveData data;
            if (!TryLoad(slot, out data)) continue;

            DateTime time;
            if (!TryParseUtc(data.savedAtUtc, out time))
            {
                try { time = File.GetLastWriteTimeUtc(SlotPath(slot)); }
                catch { time = DateTime.MinValue; }
            }

            if (bestSlot < 0 || time > bestTime)
            {
                bestSlot = slot;
                bestTime = time;
                latest = data;
            }
        }

        return bestSlot;
    }

    public static int FindLatestManualSlot(out SaveData latest)
    {
        latest = null;
        int bestSlot = -1;
        DateTime bestTime = DateTime.MinValue;

        for (int slot = 1; slot <= SlotCount; slot++)
        {
            SaveData data;
            if (!TryLoad(slot, out data)) continue;

            DateTime time;
            if (!TryParseUtc(data.savedAtUtc, out time))
            {
                try { time = File.GetLastWriteTimeUtc(SlotPath(slot)); }
                catch { time = DateTime.MinValue; }
            }

            if (bestSlot < 0 || time > bestTime)
            {
                bestSlot = slot;
                bestTime = time;
                latest = data;
            }
        }

        return bestSlot;
    }

    public static string FormatDate(SaveData data)
    {
        DateTime time;
        if (data == null || !TryParseUtc(data.savedAtUtc, out time)) return "—";
        return time.ToLocalTime().ToString("dd.MM.yyyy HH:mm", CultureInfo.InvariantCulture);
    }

    public static string FormatPlayTime(float seconds)
    {
        if (seconds < 0f) seconds = 0f;
        TimeSpan span = TimeSpan.FromSeconds(seconds);
        if (span.TotalHours >= 1d)
            return string.Format(CultureInfo.InvariantCulture, "{0:0}:{1:00}:{2:00}", (int)span.TotalHours, span.Minutes, span.Seconds);
        return string.Format(CultureInfo.InvariantCulture, "{0:00}:{1:00}", span.Minutes, span.Seconds);
    }

    public static string Describe(SaveData data)
    {
        if (data == null) return "пусто";
        return "День " + data.day + " · " + FormatDate(data);
    }

    public static HashSet<string> LoadSeen()
    {
        HashSet<string> result = new HashSet<string>();
        try
        {
            string path = Path.Combine(SaveDirectory, "seen.json");
            if (!File.Exists(path)) return result;
            SeenData data = JsonUtility.FromJson<SeenData>(File.ReadAllText(path, Encoding.UTF8));
            if (data != null && data.nodes != null)
            {
                for (int i = 0; i < data.nodes.Count; i++)
                {
                    if (!string.IsNullOrEmpty(data.nodes[i])) result.Add(data.nodes[i]);
                }
            }
        }
        catch (Exception exception)
        {
            Debug.LogWarning("[Novel] Не удалось прочитать seen.json: " + exception.Message);
        }
        return result;
    }

    public static void SaveSeen(HashSet<string> seen)
    {
        try
        {
            Directory.CreateDirectory(SaveDirectory);
            SeenData data = new SeenData();
            data.nodes = new List<string>(seen);
            File.WriteAllText(Path.Combine(SaveDirectory, "seen.json"), JsonUtility.ToJson(data), new UTF8Encoding(false));
        }
        catch (Exception exception)
        {
            Debug.LogWarning("[Novel] Не удалось записать seen.json: " + exception.Message);
        }
    }

    private static bool TryParseUtc(string raw, out DateTime time)
    {
        time = DateTime.MinValue;
        if (string.IsNullOrEmpty(raw)) return false;
        return DateTime.TryParse(raw, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out time);
    }
}

public static class NovelProgress
{
    private static HashSet<string> seen;
    private static readonly object gate = new object();

    public static void Reload()
    {
        lock (gate) { seen = SaveSystem.LoadSeen(); }
    }

    public static bool IsSeen(string dialogueId, string nodeId)
    {
        EnsureLoaded();
        return seen.Contains(Key(dialogueId, nodeId));
    }

    public static void MarkSeen(string dialogueId, string nodeId)
    {
        EnsureLoaded();
        string key = Key(dialogueId, nodeId);
        bool added;
        lock (gate) { added = seen.Add(key); }
        if (added) SaveSystem.SaveSeen(seen);
    }

    private static void EnsureLoaded()
    {
        if (seen != null) return;
        lock (gate)
        {
            if (seen == null) seen = SaveSystem.LoadSeen();
        }
    }

    private static string Key(string dialogueId, string nodeId)
    {
        return (dialogueId ?? string.Empty) + ":" + (nodeId ?? string.Empty);
    }
}
