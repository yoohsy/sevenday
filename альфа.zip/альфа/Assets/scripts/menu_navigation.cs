using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class menu_navigation : MonoBehaviour
{
    public float moveDuration = 0.9f;

    private Transform viewCamera;
    private Camera viewCam;
    private RectTransform canvasRect;
    private RectTransform mainPanel;
    private RectTransform continuePanel;
    private RectTransform settingsPanel;
    private Vector3 cameraStart;
    private Vector2 mainStart;
    private Vector2 continueStart;
    private Vector2 settingsStart;
    private Vector2 panelOffset;
    private Vector3 cameraOffset;
    private Coroutine panRoutine;

    private void Awake()
    {
        Canvas canvas = GetComponent<Canvas>();
        if (canvas != null) canvasRect = canvas.GetComponent<RectTransform>();

        viewCam = Camera.main;
        if (viewCam == null) viewCam = GetComponentInChildren<Camera>(true);
        if (viewCam != null) viewCamera = viewCam.transform;

        mainPanel = FindRect("main menu");
        continuePanel = FindRect("menu continue");
        settingsPanel = FindRect("menu setings");

        if (mainPanel != null) mainStart = mainPanel.anchoredPosition;
        if (continuePanel != null) continueStart = continuePanel.anchoredPosition;
        if (settingsPanel != null) settingsStart = settingsPanel.anchoredPosition;
        if (viewCamera != null) cameraStart = viewCamera.position;

        Wire(mainPanel, "new game", StartNewGame);
        Wire(mainPanel, "continue", OpenContinue);
        Wire(mainPanel, "setings", OpenSettings);
        Wire(continuePanel, "back", BackToMenu);
        Wire(settingsPanel, "back", BackToMenu);

        AddHoverPlates(mainPanel);
        AddHoverPlates(continuePanel);
        AddHoverPlates(settingsPanel);
    }

    private RectTransform FindRect(string trimmedName)
    {
        RectTransform[] rects = GetComponentsInChildren<RectTransform>(true);
        for (int i = 0; i < rects.Length; i++)
        {
            if (string.Equals(rects[i].name.Trim(), trimmedName, System.StringComparison.OrdinalIgnoreCase))
                return rects[i];
        }
        return null;
    }

    private void Wire(RectTransform parent, string trimmedName, UnityEngine.Events.UnityAction action)
    {
        if (parent == null) return;
        Button[] buttons = parent.GetComponentsInChildren<Button>(true);
        for (int i = 0; i < buttons.Length; i++)
        {
            if (!string.Equals(buttons[i].name.Trim(), trimmedName, System.StringComparison.OrdinalIgnoreCase)) continue;
            buttons[i].onClick.AddListener(action);
        }
    }

    private void AddHoverPlates(RectTransform panel)
    {
        if (panel == null) return;
        Button[] buttons = panel.GetComponentsInChildren<Button>(true);
        for (int i = 0; i < buttons.Length; i++)
        {
            if (buttons[i].GetComponent<button_hover_plate>() == null)
                buttons[i].gameObject.AddComponent<button_hover_plate>();
        }
    }

    public void StartNewGame()
    {
        SceneManager.LoadScene("cats");
    }

    public void OpenContinue()
    {
        PanTo(Vector2.zero - continueStart);
    }

    public void OpenSettings()
    {
        PanTo(Vector2.zero - settingsStart);
    }

    public void BackToMenu()
    {
        PanTo(Vector2.zero);
    }

    private void PanTo(Vector2 targetOffset)
    {
        Vector3 targetCameraOffset = CameraOffsetFor(targetOffset);
        if (panRoutine != null) StopCoroutine(panRoutine);
        panRoutine = StartCoroutine(Pan(targetOffset, targetCameraOffset));
    }

    private Vector3 CameraOffsetFor(Vector2 offset)
    {
        if (viewCam == null || canvasRect == null) return Vector3.zero;
        float canvasScale = Mathf.Max(0.0001f, canvasRect.lossyScale.x);
        float worldPerPixel = 2f * viewCam.orthographicSize / Mathf.Max(1f, Screen.height);
        float worldPerCanvasUnit = canvasScale * worldPerPixel;
        return new Vector3(-offset.x * worldPerCanvasUnit, -offset.y * worldPerCanvasUnit, 0f);
    }

    private IEnumerator Pan(Vector2 targetPanelOffset, Vector3 targetCameraOffset)
    {
        Vector2 fromPanel = panelOffset;
        Vector3 fromCamera = cameraOffset;
        float elapsed = 0f;
        float duration = Mathf.Max(0.01f, moveDuration);
        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.SmoothStep(0f, 1f, Mathf.Clamp01(elapsed / duration));
            panelOffset = Vector2.Lerp(fromPanel, targetPanelOffset, t);
            cameraOffset = Vector3.Lerp(fromCamera, targetCameraOffset, t);
            ApplyOffsets();
            yield return null;
        }
        panelOffset = targetPanelOffset;
        cameraOffset = targetCameraOffset;
        ApplyOffsets();
        panRoutine = null;
    }

    private void ApplyOffsets()
    {
        if (mainPanel != null) mainPanel.anchoredPosition = mainStart + panelOffset;
        if (continuePanel != null) continuePanel.anchoredPosition = continueStart + panelOffset;
        if (settingsPanel != null) settingsPanel.anchoredPosition = settingsStart + panelOffset;
        if (viewCamera != null) viewCamera.position = cameraStart + cameraOffset;
    }
}
