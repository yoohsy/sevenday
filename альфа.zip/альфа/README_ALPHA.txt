АЛЬФА — seven day cherry
========================

Unity: 2022.3.61f1
Открывать именно этой версией. Не открывать в Unity 6: проект может автоматически обновиться.

Как открыть
-----------
1. Unity Hub -> Add -> указать папку, где лежат Assets, Packages, ProjectSettings.
2. Дождаться импорта пакетов и компиляции.
3. Открыть Assets/Scenes/menu.unity и нажать Play.

Сцены
-----
- menu.unity — главное меню.
- cats.unity — основная игровая сцена.
- #1.unity — сцена с тестовым dialog panel.
- SampleScene.unity — старая сцена, оставлена в Build Settings.

В Build Settings сейчас: menu, cats, #1, SampleScene.

Что где лежит
-------------
- Assets/Resources/Dialogues — JSON-диалоги и schedule.json.
- Assets/scripts/Novel — вся логика VN: диалоги, сохранения, UI, пауза, backlog.
- Assets/Resources/Novel — сюда можно положить SpriteLibrary.asset с фонами и персонажами.

Управление
----------
- ЛКМ / Space — дальше.
- Ctrl — быстрый пропуск уже прочитанного.
- A — авто-режим.
- H — backlog.
- Esc — пауза.
- Колесо вверх — backlog.

Важно
-----
- Визуал сейчас на процедурных заглушках: реальные текстуры ещё не замаплены, SpriteLibrary.asset отсутствует.
- В сцене #1 на объекте test висит missing script. Это старый мусор, не мешает запуску, но в Console будет предупреждение.
- Сохранения пишутся в Application.persistentDataPath/Saves.
- Пакеты MCP из архива убраны: для сцен и сюжета они не нужны.

Сюжетный набросок
-----------------
Рядом лежит файл набросок.txt — исходный outline.
